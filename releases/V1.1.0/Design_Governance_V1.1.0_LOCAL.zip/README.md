# Design Governance V1.1.0 — export Local

Design Governance V1.1.0 est une expérimentation maintenue qui aide à transformer un brief en proposition de design visuellement dirigée, cultivée, spécifique, construite et polie, puis en travail vérifiable. Il peut servir pour un correctif local, une nouvelle surface, une direction visuelle ou une modification de composant partagé. Son usage recommandé est supervisé ; son efficacité réelle reste `NOT-VERIFIED`.

## Commencer en deux minutes

1. Lisez [`official/QUICKSTART.md`](official/QUICKSTART.md).
2. Si les termes `mode`, `risque`, `preuve` ou `run` sont nouveaux, lisez [`official/GLOSSAIRE.md`](official/GLOSSAIRE.md).
3. Si le besoin est déjà identifiable, consultez [`official/READING_MAP.md`](official/READING_MAP.md) pour le premier chemin et la sortie attendue.
4. Écrivez le mode, le risque dominant, la décision à changer, la prochaine preuve et l’owner.
5. Pour une décision visuelle, rendez explicites la présence, le point de vue et le niveau de polish recherchés.
6. Chargez seulement la source utile au mode retenu ; `DIRECTION/START` reste l’unique classification.

## Constitution minimale

Les cinq absolus de `official/DIRECTION.md` protègent la baseline : direction perceptible, ancre inspectable, preuves applicables, déclaration du mode et de la prochaine preuve avant l’exécution, et coordination du réel et du beau. La conformité ne remplace ni la direction ni la preuve.

Pour charger un seul bloc :

```bash
python3 scripts/read_route.py DIRECTION/START
```

Pour renforcer une carte concrète :

```bash
python3 scripts/validate_run_card.py --strict chemin/vers/run_card.json
```

Les cinq sources normatives sont `official/DIRECTION.md`, `official/ACTION.md`, `official/SAVOIR.md`, `official/BIBLIOTHEQUE.md` et `official/CHANGELOG.md`. `README.md`, `QUICKSTART.md` et `GLOSSAIRE.md` orientent la lecture sans créer de règle concurrente.

## Cas simples

| Situation | Point de départ |
|---|---|
| Corriger un défaut local, comme un contraste ou un libellé | `LITE` |
| Retoucher une surface dont la direction existe et est retrouvable | `ITER` |
| Identité, premier contact ou direction visuelle autonome | `DIRECTION` |
| Modifier un composant ou une convention partagée | `SYSTÈME` |

Classement : voir `DIRECTION/START`.

La projection machine de référence se trouve dans `schemas/run_card.example.json`. Les scripts ne nécessitent aucune dépendance Python tierce et supposent Python 3.10 ou plus récent. Pour contrôler la projection :

```bash
python3 scripts/validate_run_card.py
```

`STATE: CLOSED` signifie que la trace est persistée ; cela ne signifie pas automatiquement que le résultat est accepté ou entièrement vérifié. La validation du package ou de la `RUN_CARD` confirme uniquement les contrôles exécutés ; elle ne prouve ni l’usage, ni l’accessibilité exécutée, ni la performance, ni la qualité visuelle du produit.

Cet export est autonome : il peut être lu, utilisé et contrôlé sans connexion à un dépôt distant.

Les contrôles disponibles sont :

```bash
python3 scripts/validate_design_governance.py
python3 scripts/validate_run_card.py
python3 scripts/validate_reading_map.py
python3 scripts/read_route.py DIRECTION/START
python3 scripts/validate_all.py
```

Dans l’export Local, `validate_all.py` contrôle le package, la projection, les fixtures et la CLI ; le build et la reproductibilité restent contrôlés depuis la distribution GitHub.
