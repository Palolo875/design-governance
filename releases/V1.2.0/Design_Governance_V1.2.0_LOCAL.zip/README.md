# Design Governance V1.2.0 — export Local

Design Governance V1.2.0 est une expérimentation maintenue qui aide à transformer un brief en proposition de design visuellement dirigée, cultivée, spécifique, construite et polie, puis en travail vérifiable. Son usage recommandé est supervisé ; son efficacité réelle reste `NOT-VERIFIED`.

<!-- entree:début -->
## Commencer

Design Governance aide un agent à produire un design dirigé, construit et soigné dès la première proposition, puis à l’améliorer avec vous. Vous n’avez besoin de connaître ni les modes, ni le vocabulaire interne : l’agent s’en charge.

**1. Que demander ?** Décrivez en quelques phrases ce que vous voulez obtenir (une page, un écran, une identité, une correction), pour qui, et où cela servira : démonstration, maquette ou vrai produit. S’il s’agit d’un vrai commerce ou d’un vrai service, dites-le.

**2. Que fournir ?** Ce que vous avez déjà : textes, prix, horaires, logo, couleurs, photos (même prises au téléphone, à la lumière du jour), exemples que vous aimez, lien vers l’existant. Vos textes, votre marque et vos photos aident à produire une proposition plus spécifique et crédible. S’il en manque, l’agent vous pose d’abord au plus trois questions, en un seul message, avant de construire, seulement celles qui améliorent vraiment le résultat : contenu réel, marque, image principale ou source d’images autorisée, destination si elle est incertaine. Il construit la proposition dans tous les cas.

**3. Que recevoir ?** Une première proposition réellement construite, pas un gabarit vide. La réponse dit simplement ce qui a été fait et pourquoi, ce qui est un exemple à remplacer, ce qui manque pour la vraie version, et la suite proposée. C’est une proposition à discuter, pas une validation.

**4. Comment poursuivre ?** Validez pour continuer, réorientez ou arrêtez. Pour retenir cette direction pour votre vrai produit, dites-le : l’agent réunit alors les éléments réels et fait les vérifications nécessaires. Dites en une phrase ce qui ne va pas (« le titre écrase la photo », « trop froid pour une boulangerie ») : l’agent corrige le défaut principal, regarde de nouveau le résultat et vous dit ce qui a changé. Avant toute action irréversible ou coûteuse (publier, envoyer, payer, remplacer l’existant), il vous demande votre accord.

Pour aller plus loin : le [guide opérateur](official/QUICKSTART.md), la [skill](skill/SKILL.md) pour les agents, le [glossaire](official/GLOSSAIRE.md) et les [sources normatives](official/README.md).
<!-- entree:fin -->

## Pour les agents et les opérateurs

Un agent entre par [`skill/SKILL.md`](skill/SKILL.md) : noyau de fabrication et liste de chargement unique (`DIRECTION/CHARGE`). Pour piloter un run, lisez le guide opérateur [`official/QUICKSTART.md`](official/QUICKSTART.md) ; le vocabulaire est dans [`official/GLOSSAIRE.md`](official/GLOSSAIRE.md). Le mode d’un run est choisi par l’agent avec `DIRECTION/START` ; il n’est jamais demandé à la personne qui fait la demande.

<!-- constitution:début -->
## Constitution minimale

Les cinq absolus transversaux de `DIRECTION` forment le noyau de protection de V1 : une surface identitaire doit avoir une direction perceptible ; une direction identitaire n’est acceptée qu’avec une ancre, observée ou fournie pour un produit réel (l’exploration peut commencer sans ancre, avec sa limite déclarée) ; aucune livraison ne contourne les preuves applicables ; le mode, la preuve et le budget sont déclarés avant l’exécution ; le réel et le beau sont cadrés ensemble.

Ces absolus ne remplacent pas les procédures propriétaires d’`ACTION`, de `SAVOIR` ou de `BIBLIOTHEQUE`. Ils rappellent la priorité de gouvernance et renvoient à [DIRECTION.md](official/DIRECTION.md#les-cinq-règles-absolues), qui reste la source normative. Le piège de conformité est explicite : une conformité de surface ne vaut ni direction perceptible, ni preuve d’usage, ni qualité réelle.
<!-- constitution:fin -->

Pour charger un seul bloc :

```bash
python3 scripts/read_route.py DIRECTION/START
```

Pour renforcer une carte concrète :

```bash
python3 scripts/validate_run_card.py --strict chemin/vers/run_card.json
```

Les cinq sources normatives sont `official/DIRECTION.md`, `official/ACTION.md`, `official/SAVOIR.md`, `official/BIBLIOTHEQUE.md` et `official/CHANGELOG.md`. `README.md`, `QUICKSTART.md` et `GLOSSAIRE.md` orientent la lecture sans créer de règle concurrente.

La projection machine de référence se trouve dans `schemas/run_card.example.json`. Les scripts ne nécessitent aucune dépendance Python tierce et supposent Python 3.10 ou plus récent. Pour contrôler la projection :

```bash
python3 scripts/validate_run_card.py
```

`STATE: CLOSED` signifie que la trace est persistée ; cela ne signifie pas automatiquement que le résultat est accepté ou entièrement vérifié. La validation du package ou de la `RUN_CARD` confirme uniquement les contrôles exécutés ; elle ne prouve ni l’usage, ni l’accessibilité exécutée, ni la performance, ni la qualité visuelle du produit.

Cet export est autonome : il peut être lu, utilisé et contrôlé sans connexion à un dépôt distant.

Les contrôles disponibles sont :

```bash
python3 scripts/validate_design_governance.py
python3 scripts/validate_run_card.py
python3 scripts/validate_reading_map.py
python3 scripts/validate_structure.py
python3 scripts/read_route.py DIRECTION/START
python3 scripts/validate_all.py
```

Dans l’export Local, `validate_all.py` contrôle le package, la projection, les fixtures et la CLI ; le build et la reproductibilité restent contrôlés depuis la distribution GitHub.
