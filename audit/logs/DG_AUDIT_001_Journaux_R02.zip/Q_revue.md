# R.02 — Revue bornée du diff V1.1.0 → V1.1.1 (contradictions)

**Périmètre :** `diff_textes_V1.1.0_V1.1.1.diff` (33 hunks), confronté à `pkg/` (textes, `schemas/run_card.schema.json`, `scripts/validate_run_card.py`). Lecture seule. Le build n'a pas été lancé. Seules deux exécutions ont eu lieu, en lecture : `read_route.py` sur les locators introduits, et `validate_card` en mémoire sur des copies non écrites de `run_card.example.json` (sans `__pycache__`).
**Locators introduits par le diff :** tous résolvent (`ACTION/STATUS`, `ACTION/GATE-A/B/C`, `BIBLIOTHEQUE/TENSION`, `ACTION/POLICIES`, `SAVOIR/TOOLS`, `DIRECTION/FIRST-OBJECT`, `DIRECTION/VISUAL_TARGET`, `ACTION/RUN_CARD`, `ACTION/CLOSE-PACKAGE`, `ACTION/HANDOFF`). Les chemins cités par l'encadré des exemples (`schemas/run_card.example.json`, `scripts/validate_run_card.py`, `machine_projection.md`) existent dans les deux distributions.
**Fusion RUN-\* → CLOSE-PACKAGE :** aucun élément perdu. J'ai comparé, mode par mode, les lignes supprimées aux lignes ajoutées. Les résidus relevés sont des doublons restants (Q-08), pas des pertes.

## Constats (du plus grave au moins grave)

### Q-01 — S — certain — Droits inconnus : le texte attribue à la machine un contrôle que le validateur limite à DIRECTION
- **A** `V1/official/ACTION.md:667` (ajouté) : « Un droit inconnu (`rights_status` : `unknown`) interdit `ACCEPTED` ; […] La machine contrôle seulement l'exclusion d'`ACCEPTED` ; la réserve sur les droits reste à la trace. »
- **B** `scripts/validate_run_card.py:319` : `if mode == "DIRECTION" and verdict == "ACCEPTED" and (card.get("artifact") or {}).get("rights_status") == "unknown":`
- **Conflit.** Le texte est placé dans la fiche d'asset directeur. Celle-ci se déclenche dans tout mode où un asset porte une décision (`ACTION.md:605`). Or le validateur n'exclut `ACCEPTED` qu'en `DIRECTION`. Vérifié en mémoire : une carte `STANDARD` `ACCEPTED` avec `rights_status: unknown` est déclarée VALID. Il s'agit d'un texte contre machine. Le passage voisin `ACTION.md:500` est, lui, correctement borné (« Dans une `RUN_CARD` `DIRECTION` […] pas d'`ACCEPTED` »).

### Q-02 — S — probable — Paquet SYSTÈME sans conséquence décisionnelle, alors que les notes de version annoncent l'alignement de « les paquets de clôture »
- **A** `V1/official/ACTION.md:466` (ajouté) : « **SYSTÈME** | Décision de système, impact, consumers, owner, migration/rollback, non-régression, réserves, verdict et entrée CHANGELOG. »
- **B** `V1/official/CHANGELOG.md:12` : « La table `RUN_CARD`, le glossaire, la réponse visible et les paquets de clôture renvoient à la triade d'`ACTION/STATUS` […] ». Même affirmation dans `RELEASE_NOTES.md:22`. Voir aussi `scripts/validate_run_card.py:322-323` : `CLOSED` et mode dans `{"ITER", "STANDARD", "DIRECTION", "SYSTÈME"}` sans `decision_change`, donc erreur.
- **Conflit.** Quatre paquets sur cinq reçoivent la triade ; la ligne SYSTÈME, non. Pourtant, la machine exige `decision_change` pour une carte SYSTÈME close et acceptée. Le paquet défini « une seule fois » omet donc un élément requis par la machine, et l'annonce du CHANGELOG est fausse pour ce mode.

### Q-03 — S — probable — Le défaut RET-1 subsiste dans SAVOIR : `N/A-JUSTIFIED` y reste la seule sortie en l'absence de conséquence
- **A** `V1/official/SAVOIR.md:879`, dans le bloc `[REQUIS PAR LE MODULE — avant verdict DIRECTION …]`, colonne « Bloque si… » : « Aucune décision modifiée, confirmée ou abandonnée sans justification `N/A-JUSTIFIED`. »
- **B** `V1/official/ACTION.md:168` : « `N/A-JUSTIFIED` (aucune conséquence applicable, avec raison) · `NOT-OBSERVED` (conséquence attendue absente ; interdit `ACCEPTED`) ». Voir aussi la ligne réécrite `ACTION.md:295`.
- **Conflit.** Une conséquence attendue mais non observée (`NOT-OBSERVED`) bloque selon SAVOIR, sauf si elle est reformulée en `N/A-JUSTIFIED`. C'est exactement la faute visée par RET-1. ACTION et la machine admettent au contraire `NOT-OBSERVED` avec un verdict non `ACCEPTED`. LCF-22 ne détecte pas cette ligne, parce qu'elle ne contient pas l'énumération des valeurs. Copie mineure du même défaut : `SAVOIR.md:30` (« Si aucune décision ne change, retournez `N/A-JUSTIFIED` »). Ce texte ignore `NOT-OBSERVED` et range la confirmation parmi les cas sans changement.

### Q-04 — m — probable — Paquets ITER et STANDARD : « contrôle machine : forme seule » alors que `decision_change` est contrôlé
- **A** `V1/official/ACTION.md:463-464` (ajoutés) : « … et conséquence décisionnelle (`DECISION-CHANGE`, `N/A-JUSTIFIED` ou `NOT-OBSERVED`). | Forme seule, dans la trace. » Voir aussi `ACTION.md:392` : « pour `LITE`, `ITER` et `STANDARD`, le paquet de clôture vit dans la trace et la machine ne le vérifie pas ».
- **B** `scripts/validate_run_card.py:322-323`, et le cas `C1-3` (`:765`) : une carte `STANDARD` sans `decision_change` est rejetée. Vérifié en mémoire.
- **Conflit.** La fusion place dans les lignes ITER et STANDARD un élément que la machine contrôle, sous la mention « forme seule ». La tension existait déjà pour les axes et le verdict, contrôlés dans tous les modes. Le diff l'étend (auparavant, `DECISION-CHANGE` en STANDARD ne figurait que dans RUN-STANDARD, sans colonne machine).

### Q-05 — m — probable — Exemple du QUICKSTART §9 : `CHANGE` y garde l'ancien sens, contraire à la nouvelle définition
- **A** `V1/official/QUICKSTART.md:252-253` : « CHANGE: Rapprocher l'objet et le titre, réduire la saillance du CTA secondaire et réviser le crop. » ; puis `:255-256` : « DECISION-CHANGE: Le défaut de hiérarchie est réel ; la correction modifie l'artefact et doit être réobservée. »
- **B** `V1/official/ACTION.md:45` (ajouté) : « `CHANGE` vaut la conséquence décisionnelle d'`ACTION/STATUS` : décision changée, confirmée ou abandonnée, `N/A-JUSTIFIED` ou `NOT-OBSERVED`. »
- **Conflit.** L'exemple complet de la façade emploie `CHANGE` au sens de « correction à faire ». Sa valeur `DECISION-CHANGE` n'appartient pas à la triade : elle annonce un changement avant la réobservation. LCF-22 exclut les lignes `DECISION-CHANGE:`, donc la liste close ne voit pas cet écart.

### Q-06 — m — certain — Chargement LITE/ITER : le QUICKSTART §5 n'a pas été aligné
- **A** `V1/official/QUICKSTART.md:153-154` : « `LITE` | `DIRECTION/START`, `ACTION/RUN-LITE`, `ACTION/FAST-PATH`. » et « `ITER` | `DIRECTION/START`, `ACTION/RUN-ITER`, direction existante. »
- **B** `V1/official/ACTION.md:17-18` et `skills/design-governance-practice/SKILL.md:95-96` (ajoutés) : « `ACTION/GATE-A` applicable et `ACTION/GATE-B` du risque dominant / touché ».
- **Conflit.** Il s'agit d'une omission, pas d'une interdiction. RET-4 corrige la skill et la carte d'ACTION, mais la troisième projection de la même table (la colonne « Charger d'abord » du QUICKSTART) ne charge toujours pas les gates A et B en LITE et ITER. `DIRECTION/DAILY` (`DIRECTION.md:255-256`) est dans le même cas, mais elle se déclare « vue de chargement » (écart plus faible).

### Q-07 — m — probable — Nouvelle ligne de correspondance : double projection de `SCOPE` et source de « contrainte » discutable
- **A** `V1/official/ACTION.md:323` (ajouté) : « Direction qualifiée : premier objet (`DIRECTION/FIRST-OBJECT`), contrainte (`DIRECTION/VISUAL_TARGET`, « Qualifier la direction ») ; périmètre (`SCOPE`) | avant build | `direction.first_object`, `.constraint`, `.scope` »
- **B** `V1/official/ACTION.md:312` : « SCOPE, ARTIFACT | avant build, puis clôture | `artifact.scope`, … » ; et `V1/official/DIRECTION.md:155-156` (`DIRECTION/START`, « Entrée minimale ») : « SCOPE — … » / « CONSTRAINT — contrainte réelle qui peut changer la décision ».
- **Conflit.** Le champ canonique `SCOPE` reçoit désormais deux projections explicites (`artifact.scope` et `direction.scope`), sans règle de partage. Par ailleurs, la « contrainte » est rattachée à un paragraphe de définition (« Qualifier la direction ») plutôt qu'au champ `CONSTRAINT` de `DIRECTION/START`, qui n'a aucune autre ligne de projection. R-08 visait justement à rattacher chaque élément à sa vraie source.

### Q-08 — m — certain — « Sortie définie une seule fois » : des listes par mode restent hors de CLOSE-PACKAGE
- **A** `V1/official/ACTION.md:440` : « **Sortie.** Paquet `DIRECTION` d'`ACTION/CLOSE-PACKAGE`. Pour chaque ancrage mobilisé, distinguer si nécessaire son rôle […], les attributs retenus et rejetés, la transformation effectuée et les limites de transfert […] ». Idem `:450` (RUN-SYSTEM, liste `closure.system_package`). La table `ACTION/PRECONDITION` (`:221-225`, « Contrat ACTION minimal » par mode) en est une troisième.
- **B** `V1/official/ACTION.md:23` : « La sortie à conserver de chaque mode est définie une seule fois, par `ACTION/CLOSE-PACKAGE`. » Voir aussi `CHANGELOG.md:14` et `RELEASE_NOTES.md:22` (« sorties par mode définies une seule fois »).
- **Conflit.** Rien n'est perdu, mais les exigences de sortie sur les ancrages en DIRECTION restent seulement dans RUN-DIRECTION : absentes de la ligne DIRECTION du paquet (`:465`), elles conservent une seconde définition. L'affirmation « une seule fois » n'est donc pas littéralement vraie.

### Q-09 — m — probable — Nouvelle portée de B1b contre branche one-shot en DIRECTION
- **A** `V1/official/ACTION.md:787` (ajouté) : « `B1b` est **requis par module** sur toute surface `DIRECTION` qui accepte […] avec l'axe V en `PASS` ou `PASS-WITH-RESERVATION` : un V positif n'y est pas accordé sans une décision principale confrontée à une variante […]. Le déclencheur […] ne dépend pas de l'affirmation qu'une comparaison « ne changerait rien ». » Même portée en `DIRECTION.md:241`.
- **B** `V1/official/DIRECTION.md:498` : « Après le build, vérifie : capture réelle […], revue créative, vérification du risque dominant […]. Tu peux t'arrêter après cette observation si […] aucune amélioration utile ne promet un gain réel. » Voir aussi `ACTION.md:520`.
- **Conflit.** Un one-shot DIRECTION accepté avec V positif exige désormais, en texte, une paire de captures ou l'un des deux motifs N/A. La liste de contrôles du one-shot ne mentionne pas B1b. On peut concilier les deux par « les risques applicables sont couverts », mais la lecture littérale autorise un arrêt après une seule capture.

### Q-10 — m — certain — GLOSSAIRE : la ligne réécrite appelle « complète » une réserve à six attributs
- **A** `V1/official/GLOSSAIRE.md:59` (réécrit) : « il porte une réserve complète (owner, portée, impact, prochaine preuve, date de revue, condition de sortie) ».
- **B** `V1/official/ACTION.md:482-494` (sept attributs, dont `DATE / VERSION`) ; `scripts/validate_run_card.py:189` : `RESERVATION_FIELDS = (…, "date_version", …)`.
- **Conflit.** L'écart existait déjà, mais la ligne a été réécrite sans le corriger. Il oppose une façade à la machine sur la liste des attributs d'une réserve.

### Q-11 — m — probable — Droits inconnus : réserve admise, contre « pas acceptable par simple mention dans la trace »
- **A** `V1/official/ACTION.md:667` (ajouté) : « `ACCEPTED-WITH-RESERVATION` reste possible avec une réserve structurée […] ; la réserve sur les droits reste à la trace. »
- **B** `V1/official/ACTION.md:500` : « En cas de doute sur un droit […], la sortie reste limitée, bloquée ou escaladée selon le risque ; elle ne devient pas acceptable par simple mention dans la trace. »
- **Conflit.** Les deux textes se concilient si « limitée » désigne une acceptation réservée sans diffusion. Mais « acceptable » (`:500`) et « `ACCEPTED-WITH-RESERVATION` reste possible […] reste à la trace » (`:667`) se lisent en sens opposés, et `:500` n'a pas été ajusté.

### Q-12 — m — probable — Légende : tag « partagé » « au même sens », avec une forme et une définition différentes
- **A** `V1/official/DIRECTION.md:107` (ajouté) : « Légende commune à DIRECTION et SAVOIR pour les seuls tags partagés : `[REQUIS PAR LE MODULE]`, `[À ADAPTER]` et `[VEILLE]`, au même sens. » Voir aussi la définition `DIRECTION.md:102` : « Obligation définie par ACTION, SAVOIR ou BIBLIOTHEQUE dans son propre périmètre. »
- **B** `V1/official/SAVOIR.md:56` : « `[REQUIS PAR LE MODULE — scope]` | Obligation spécialisée. | Exécuter ou déclarer `N/A-JUSTIFIED` dans le scope. »
- **Conflit.** SAVOIR n'emploie jamais la forme nue `[REQUIS PAR LE MODULE]` (0 occurrence). Sa forme porte un scope et une règle d'usage absente de DIRECTION. « Au même sens » est donc une affirmation de légende plus forte que les deux tables. La nouvelle phrase répare F-DIR-005 pour `[RECOMMANDÉ]`, mais en introduit une plus faible.

### Q-13 — m — probable — RET-6 : d'autres affirmations de cohérence restent non bornées
- **A** `RELEASE_NOTES.md:59` : « Ces contrôles établissent la cohérence documentaire et technique du package. » Voir aussi `RELEASE_NOTES.md:11` (« présentée comme un système cohérent ») et `README.md:143` (« Ces contrôles établissent la cohérence du package, de ses projections et de ses distributions. »).
- **B** `RELEASE_NOTES.md:20` (ajouté) : « la cohérence opposable se limite à la liste close des conditions de façade (`validate_reading_map.py`) : une divergence hors de cette liste n'est pas détectée. »
- **Conflit.** Dans le même fichier, une phrase non bornée affirme la cohérence documentaire que la nouvelle phrase restreint. Q-01 à Q-12 en montrent des exemples concrets.

---

**Bloquants : 0 ; significatifs : 3 ; mineurs : 10**

**Hunks examinés sans constat :**
- `README.md` @@1-10 (version).
- `RELEASE_NOTES.md` @@1-12 (version, présentation) ; @@15 « 35 conditions de façade » (vérifié : 35 entrées LCF dans `validate_reading_map.py`) ; @@65 (limites).
- `ACTION.md` @@292 (ligne `DECISION-CHANGE`, cohérente avec `ACTION/STATUS` et le validateur `:324`) ; @@406 (Sortie RUN-LITE).
- `CHANGELOG.md` en-tête et bullets V1.1.1 hors « paquets » et « sorties » (B1b, façades, textes normatifs, 21 → 35, erratum ; « cartes valides en V1.1.0 le restent » : aucune modification du schéma ni du validateur).
- `GLOSSAIRE.md` @@35 (`DECISION-CHANGE`).
- `QUICKSTART.md` @@1 (version) ; @@42 (Creative Boot, conforme à `DIRECTION.md:175` et `BIBLIOTHEQUE/TENSION`) ; @@164 (§6 « Retour si… », identique mot pour mot à `DIRECTION/FIRST-OBJECT`).
- `V1/official/README.md` @@1 (version).
- `SAVOIR.md` @@779 (sept champs : conforme à `ACTION.md:952-958`).
- `scripts/build_distributions.sh` et `scripts/package_manifest.json` (version).
- `SKILL.md` @@116 (Creative Boot).
- `examples.md` @@1 (encadré « Trace, pas sérialisation »).
- `machine_projection.md` @@117 (axes conformes à `closure.axes` du schéma ; `profile_decision` à cinq champs, conforme à `required` du schéma).

**Hunks rattachés aux constats :**
- `ACTION.md` @@15 → Q-06 ; @@42 → Q-05 ; @@319 → Q-07 ; @@416/@@426 → Q-04 ; @@436 → Q-08 ; @@446 → Q-02, Q-08 ; @@458 → Q-02, Q-04 ; @@663 → Q-01, Q-11 ; @@783 → Q-09.
- `CHANGELOG.md` @@1 → Q-02, Q-08 ; @@12 → Q-13.
- `DIRECTION.md` @@104 → Q-12 ; @@238 → Q-09.
- `GLOSSAIRE.md` @@56 → Q-10.
- `RELEASE_NOTES.md` @@15 (« Retour d'audit », « Façades ») → Q-02, Q-08, Q-13.
- `SKILL.md` @@92 → Q-06.
- RET-1 (`ACTION.md` @@292, `GLOSSAIRE.md` @@35) → Q-03 (copies restantes dans SAVOIR).
