import json, hashlib, datetime
from pathlib import Path
from playwright.sync_api import sync_playwright
D=Path('.').resolve(); OUT=D/'captures'; OUT.mkdir(exist_ok=True)
P=f"file://{D}/phase6_02_pilotes.html"; H=f"file://{D}/phase6_02_mobile_harness.html"
log={'date':datetime.datetime.now().isoformat(timespec='seconds'),'files':{f:hashlib.sha256((D/f).read_bytes()).hexdigest() for f in ['phase6_02_pilotes.html','phase6_02_mobile_harness.html']},'shots':[],'metrics':{}}
METRICS_JS=r"""
() => {
 function lum(c){const m=c.match(/[\d.]+/g); if(!m) return null; const [r,g,b,a]=m.map(Number); if(a!==undefined && a<1) return {partial:true, v:[r,g,b]}; const f=x=>{x/=255;return x<=0.03928?x/12.92:Math.pow((x+0.055)/1.055,2.4)}; return {v:[r,g,b], L:0.2126*f(r)+0.7152*f(g)+0.0722*f(b)}}
 function bg(el){while(el){const s=getComputedStyle(el); if(s.backgroundImage!=='none') return {img:true,c:s.backgroundColor}; const c=s.backgroundColor; if(c && !c.includes('rgba(0, 0, 0, 0)') && c!=='transparent'){const l=lum(c); if(l && !l.partial) return {c,L:l.L}} el=el.parentElement} return {c:'rgb(255,255,255)',L:1}}
 const out=[]; const seen=new Set();
 for(const el of document.querySelectorAll('body *')){
  const r=el.getBoundingClientRect(); const s=getComputedStyle(el);
  if(r.width===0||s.visibility==='hidden'||s.display==='none') continue;
  const txt=[...el.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent.trim()).join(' ').trim();
  if(!txt) continue;
  const fg=lum(s.color); const b=bg(el); if(!fg) continue;
  const ratio = b.img? null : ((Math.max(fg.L,b.L)+0.05)/(Math.min(fg.L,b.L)+0.05));
  const size=parseFloat(s.fontSize), w=parseInt(s.fontWeight);
  const large = size>=24 || (size>=18.66 && w>=700);
  out.push({t:txt.slice(0,50),fs:size,fw:w,color:s.color,bg:b.c,bgImage:!!b.img,ratio:ratio&&Math.round(ratio*100)/100,need:large?3:4.5});
 }
 const doc=document.documentElement;
 return {overflowX: doc.scrollWidth>doc.clientWidth, scrollW:doc.scrollWidth, clientW:doc.clientWidth, height:doc.scrollHeight,
   fonts:[...new Set([...document.querySelectorAll('body *')].map(e=>getComputedStyle(e).fontFamily))].slice(0,6),
   texts:out}
}"""
with sync_playwright() as p:
    b=p.chromium.launch(); log['browser']='Chromium '+b.version
    def shot(name,url,vw,vh,full=True,actions=None,metrics=False):
        pg=b.new_page(viewport={'width':vw,'height':vh}); pg.goto(url); pg.wait_for_timeout(700)
        notes=[]
        if actions: notes=actions(pg) or []
        fn=OUT/f'{name}.png'; pg.screenshot(path=str(fn),full_page=full)
        entry={'name':name,'url':url.replace(str(D),'.'),'viewport':f'{vw}x{vh}','full_page':full,'notes':notes}
        if metrics: log['metrics'][name]=pg.evaluate(METRICS_JS)
        log['shots'].append(entry); pg.close()
    DW,DH=1440,900
    shot('A1_sound_normal_desktop',P+'?case=sound',DW,DH,metrics=True)
    shot('A2_sound_unavailable_desktop',P+'?case=sound&state=unavailable',DW,DH)
    def listen(pg):
        has=pg.evaluate("()=>!!(window.AudioContext||window.webkitAudioContext)")
        pg.click('#listen'); pg.wait_for_timeout(600)
        return [f'AudioContext disponible={has}', 'statut après clic: '+pg.inner_text('#soundStatus')]
    shot('A3_sound_after_listen_desktop',P+'?case=sound',DW,DH,full=False,actions=listen)
    def toggle(pg):
        pg.click('#soundToggle'); pg.wait_for_timeout(300)
        return ['statut après bascule: '+pg.inner_text('#soundStatus'), 'listen disabled='+str(pg.is_disabled('#listen'))]
    shot('A4_sound_toggle_unavailable_desktop',P+'?case=sound',DW,DH,full=False,actions=toggle)
    shot('B1_incident_normal_desktop',P+'?case=incident',DW,DH,metrics=True)
    shot('B2_incident_unavailable_desktop',P+'?case=incident&state=unavailable',DW,DH)
    shot('B3_incident_success_desktop',P+'?case=incident&state=success',DW,DH)
    def assign(pg):
        pg.click('#assign'); pg.wait_for_timeout(300)
        return ['après clic assign: bouton="'+pg.inner_text('#assign')+'" ; résultat visible='+str(pg.is_visible('#assignResult'))+' ; responsable='+pg.inner_text('#incidentOwner')]
    shot('B4_incident_after_assign_click_desktop',P+'?case=incident',DW,DH,full=False,actions=assign)
    def retry(pg):
        pg.click('text=Source indisponible'); pg.wait_for_timeout(200); pg.click('#retry'); pg.wait_for_timeout(200)
        return ['après indisponible puis retry: vue normale visible='+str(pg.is_visible('#incidentNormal'))]
    shot('B5_incident_retry_desktop',P+'?case=incident',DW,DH,full=False,actions=retry)
    # mobile harness (as specified in 6.02) and direct 390 viewport
    for c,st in [('sound',None),('incident',None),('incident','unavailable')]:
        q=f'?case={c}'+(f'&state={st}' if st else '')
        shot(f'M_harness_{c}_{st or "normal"}',H+q,470,960,full=True)
        shot(f'M_direct390_{c}_{st or "normal"}',P+q,390,844,full=True,metrics=(st is None))
    # keyboard focus
    for c in ['sound','incident']:
        pg=b.new_page(viewport={'width':DW,'height':DH}); pg.goto(P+f'?case={c}'); pg.wait_for_timeout(500)
        seq=[]
        for i in range(8):
            pg.keyboard.press('Tab'); pg.wait_for_timeout(80)
            info=pg.evaluate("()=>{const e=document.activeElement; const s=getComputedStyle(e); return {tag:e.tagName, id:e.id, text:(e.innerText||'').slice(0,40), outline:s.outlineStyle+' '+s.outlineWidth+' '+s.outlineColor, shadow:s.boxShadow}}")
            seq.append(info)
            if i==1: pg.screenshot(path=str(OUT/f'K_{c}_focus_tab2.png'))
        log['metrics'][f'keyboard_{c}']=seq; pg.close()
    b.close()
json.dump(log,open(OUT/'observation_log.json','w'),ensure_ascii=False,indent=1)
print('ok',len(log['shots']))
