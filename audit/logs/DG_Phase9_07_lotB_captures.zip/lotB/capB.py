import json
from pathlib import Path
from playwright.sync_api import sync_playwright
D=Path(__file__).resolve().parents[1]; O=D/'lotB'
AXE=Path('/tmp/axe/node_modules/axe-core/axe.min.js').read_text()
def url(f='phase6_02_pilotes.html',q='?case=incident'): return f'file://{D}/{f}{q}'
LONG=r"""()=>{
 const set=(sel,t)=>{const e=document.querySelector(sel); if(e) e.textContent=t;};
 const h=[...document.querySelectorAll('.incident h1, .incident h2, .incident h3')];
 const main=[...document.querySelectorAll('.incident h2')].find(e=>e.textContent.includes('Convoyeur 07'));
 if(main) main.textContent='Convoyeur 07 du bâtiment de conditionnement secondaire à l’arrêt depuis la dernière séquence de maintenance préventive';
 set('#incidentOwner','Équipe d’astreinte maintenance électromécanique — secteur Nord-Est');
 set('#incidentAge','Il y a 1 h 47 min');
 set('#incidentTag','Critique · à traiter · priorité absolue');
 const li=[...document.querySelectorAll('.inc-list h3, .inc-list strong, .inc-list b, .inc-list p')];
 const t=[...document.querySelectorAll('.inc-list *')].find(e=>e.children.length===0 && e.textContent.includes('Arrêt du convoyeur'));
 if(t) t.textContent='Arrêt du convoyeur 07 — Hochgeschwindigkeitsverpackungsanlage Nord';
 return !!main;
}"""
METRICS=r"""()=>{
 const doc=document.documentElement; const res={overflowX:doc.scrollWidth>doc.clientWidth, scrollW:doc.scrollWidth, vw:doc.clientWidth, clipped:[], overlaps:[], targets:[]};
 for(const el of document.querySelectorAll('.incident *')){const s=getComputedStyle(el); const r=el.getBoundingClientRect(); if(!r.width||s.display==='none'||s.visibility==='hidden') continue;
   if(el.children.length===0 && el.textContent.trim() && el.scrollWidth>el.clientWidth+1 && s.overflowX!=='visible') res.clipped.push(el.textContent.trim().slice(0,40));
   if(el.children.length===0 && el.textContent.trim() && r.right>doc.clientWidth+1) res.clipped.push('HORS ÉCRAN: '+el.textContent.trim().slice(0,40));}
 const cells=[...document.querySelectorAll('.incident .inc-main *')].filter(e=>e.children.length===0&&e.textContent.trim()&&e.getBoundingClientRect().width);
 for(let i=0;i<cells.length;i++)for(let j=i+1;j<cells.length;j++){const a=cells[i].getBoundingClientRect(),b=cells[j].getBoundingClientRect(); if(a.left<b.right-1&&b.left<a.right-1&&a.top<b.bottom-1&&b.top<a.bottom-1) res.overlaps.push([cells[i].textContent.trim().slice(0,25),cells[j].textContent.trim().slice(0,25)])}
 for(const b of document.querySelectorAll('.incident button')){const r=b.getBoundingClientRect(); if(r.width) res.targets.push([b.textContent.trim().slice(0,22),Math.round(r.width),Math.round(r.height)])}
 return res;}"""
log={}
with sync_playwright() as p:
    br=p.chromium.launch()
    def page(vw,vh,js=True,**kw):
        ctx=br.new_context(viewport={'width':vw,'height':vh},java_script_enabled=js,**kw); return ctx,ctx.new_page()
    # 1-2 viewports nominal + long content
    for vw,vh in [(1440,900),(800,1000),(390,844),(320,700)]:
        for long in (False,True):
            ctx,pg=page(vw,vh); pg.goto(url()); pg.wait_for_timeout(400)
            if long: pg.evaluate(LONG); pg.wait_for_timeout(200)
            n=f"B_{'long' if long else 'nominal'}_{vw}"
            pg.screenshot(path=str(O/f'{n}.png'),full_page=True); log[n]=pg.evaluate(METRICS); ctx.close()
    # 4 axe on states
    for st,vw in [('normal',1440),('unavailable',1440),('success',1440),('normal',390)]:
        ctx,pg=page(vw,900); pg.goto(url(q=f'?case=incident&state={st}')); pg.wait_for_timeout(300)
        pg.add_script_tag(content=AXE)
        r=pg.evaluate("async()=>{const r=await axe.run(document,{resultTypes:['violations']}); return r.violations.map(v=>({id:v.id,impact:v.impact,n:v.nodes.length,help:v.help,targets:v.nodes.slice(0,4).map(x=>x.target.join(' '))}))}")
        log[f'axe_{st}_{vw}']=r; ctx.close()
    # 5 accessibility tree
    ctx,pg=page(1440,900); pg.goto(url()); pg.wait_for_timeout(300)
    log['aria_snapshot']=pg.locator('.incident').aria_snapshot(); ctx.close()
    # 6 critical state sequence
    ctx,pg=page(1440,900); pg.goto(url()); pg.wait_for_timeout(300)
    seq=[]; pg.click('#assign'); seq.append(('après assign',pg.inner_text('#incidentOwner'),pg.inner_text('#incidentTag')))
    pg.click('text=Source indisponible'); pg.wait_for_timeout(150); seq.append(('puis source indisponible',pg.is_visible('#incidentNormal'),pg.inner_text('#incidentUnavailable')[:80]))
    pg.screenshot(path=str(O/'B_seq_assign_puis_indispo.png'))
    pg.click('#retry'); pg.wait_for_timeout(150); seq.append(('puis retour',pg.inner_text('#incidentOwner'),pg.inner_text('#incidentTag'),pg.inner_text('#assign')))
    pg.screenshot(path=str(O/'B_seq_apres_retour.png'))
    log['sequence_etat_critique']=seq; ctx.close()
    # 7 runtime variants
    ctx,pg=page(1440,900,js=False); pg.goto(url()); pg.wait_for_timeout(300); pg.screenshot(path=str(O/'B_runtime_sans_JS.png'),full_page=True)
    log['runtime_sans_js']={'h':pg.evaluate("document.documentElement.scrollHeight"),'sound_visible':pg.is_visible('.sound'),'incident_visible':pg.is_visible('.incident')}; ctx.close()
    ctx,pg=page(1440,900,device_scale_factor=2); pg.goto(url()); pg.wait_for_timeout(300); pg.screenshot(path=str(O/'B_runtime_dpr2.png')); ctx.close()
    ctx,pg=page(1440,900,reduced_motion='reduce'); pg.goto(url()); pg.wait_for_timeout(300); pg.screenshot(path=str(O/'B_runtime_reduced_motion.png')); ctx.close()
    ctx,pg=page(1440,900,forced_colors='active'); pg.goto(url()); pg.wait_for_timeout(300); pg.screenshot(path=str(O/'B_forced_colors.png'))
    pg.emulate_media(forced_colors='active'); ctx.close()
    ctx,pg=page(1440,900); pg.goto(url()); pg.emulate_media(media='print'); pg.wait_for_timeout(200); pg.screenshot(path=str(O/'B_runtime_print.png'),full_page=True); ctx.close()
    br.close()
json.dump(log,open(O/'lotB_log.json','w'),ensure_ascii=False,indent=1)
print('ok')
