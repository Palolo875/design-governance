# R.03 — Revue bornée des correctifs de textes (contradictions)

**Périmètre.** La revue porte sur `diff_textes_R03.diff` (10 hunks, 8 fichiers). Elle les confronte à `pkg/` : textes, `schemas/run_card.schema.json`, `scripts/validate_run_card.py`, et, pour les décomptes et les LCF, `scripts/validate_reading_map.py`. Tout s'est fait en lecture seule : aucun script exécuté, aucun build lancé.

**Vérifications de base :**
- **Références.** Les locators cités par les nouveaux textes (`ACTION/STATUS`, `ACTION/RUN_CARD`, `ACTION/GATE-A`, `ACTION/GATE-B`) existent comme sections ; aucune référence cassée.
- **Décompte « 42 conditions de façade ».** Il est exact : LCF-01 à 17, LCF-C1 et C2, puis LCF-20 à 42, soit 17 + 2 + 23 = 42. Aucune mention résiduelle de « 35 ».
- **O-1.** Le schéma admet `null` en trois endroits exactement : `risk.critical_protection` (`"type": ["object", "null"]`, :29), `closure.issue` (:192) et `closure.verdict` (:193). La liste d'`ACTION.md:386` est donc exacte.

## Constats

### T-01 — S — probable — QUICKSTART §9 : `DECISION-CHANGE` présente comme acquise une recomposition non encore observée
- **A** `V1/official/QUICKSTART.md:256` : « CHANGED — la composition mobile du premier rendu est abandonnée : l’objet visuel rejoint le titre et le CTA secondaire recule (observation : capture mobile 390). L’effet de la correction reste à réobserver. » Voir aussi `:253` (« CORRECTION: Rapprocher l’objet et le titre… », à l'impératif) et `:262` (« NEXT-ACTION: Réobserver le mobile… »).
- **B** `V1/official/ACTION.md:243` : « Ne déclare jamais un changement avant qu’une observation ne l’ait rendu réel. » ; `ACTION.md:261` : « Seul un résultat observé dans le scope déclaré peut alimenter `DECISION-CHANGE` et un verdict. » Comparer avec `GLOSSAIRE.md:57`, où `CHANGED` s'appuie sur une « capture avant/après ».
- **Conflit.** L'abandon de la première composition repose bien sur une observation, la capture du premier rendu. En revanche, la phrase décrit la nouvelle composition à l'indicatif (« rejoint », « recule ») et cite comme preuve cette même capture, alors qu'elle déclare elle-même l'effet « à réobserver ». La valeur mêle donc un changement observé et un changement annoncé, ce que `ACTION.md:243` interdit. Le reste du correctif est conforme : `STATE: CHECKING` admet `DECISION-CHANGE` (`ACTION.md:243`, dernière phrase ; `check_time`, `validate_run_card.py:267-273`), et la valeur appartient à l'énumération `OUTCOME` (LCF-42). Une valeur `ABANDONED` limitée à l'abandon, avec la recomposition laissée dans `CORRECTION`, lèverait l'écart.

### T-02 — m — probable — Règle d'omission trop large : « un autre champ sans valeur est omis » vaut aussi pour des champs requis
- **A** `V1/official/ACTION.md:386` : « Seuls `closure.issue`, `closure.verdict` et `risk.critical_protection` admettent `null` ; un autre champ sans valeur est omis (par exemple `closure.direction_status` hors surface `DIRECTION`). » Même formule dans `skills/design-governance-practice/references/machine_projection.md:120` : « sinon le champ est omis ».
- **B** `schemas/run_card.schema.json:12` : `"required": [..., "artifact", "proof", "next_proof", "closure"]`. En `DIRECTION`, `:311` ajoute `"anchors"` et `"trace_locator"`. `ACTION.md:552` : « Une ancre manquante se sérialise par l’issue — ancres vides, issue non nulle […] ».
- **Conflit.** La règle ne se limite pas aux champs facultatifs. Appliquée à un champ requis sans valeur (ancres absentes en `DIRECTION`, `next_proof` inconnu), elle conduit à une omission que le schéma rejette. Pour les ancres, `ACTION.md:552` prescrit au contraire un tableau vide. Formulation attendue : « un champ facultatif sans valeur est omis ».

### T-03 — m — probable — SAVOIR : la sortie renvoie `NOT-OBSERVED`, valeur « après observation », depuis un module qui sort aussi avant le build
- **A** `V1/official/SAVOIR.md:30` : « Elle doit transmettre à ACTION […] la conséquence observable, la preuve attendue […] Si aucune décision n’est changée, confirmée ou abandonnée, retournez la triade d’`ACTION/STATUS` — `N/A-JUSTIFIED` […], `NOT-OBSERVED` lorsqu’une conséquence attendue n’a pas été observée […] ».
- **B** `V1/official/ACTION.md:243` : « `DECISION-CHANGE` et le creative close sont des champs « après observation » : ils restent absents tant que le run n’a pas atteint `CHECKING`. » Côté machine, `validate_run_card.py:272-273` refuse `decision_change` avant l'observation.
- **Conflit.** La sortie de SAVOIR décrite ici est une sortie de jugement : conséquence *observable*, preuve *attendue*. Elle peut donc intervenir avant le build. Le nouveau texte lui fait « retourner » une valeur de la triade que la carte ne peut pas encore porter. Le texte précédent avait le même défaut de phase avec `N/A-JUSTIFIED`. L'ajout de `NOT-OBSERVED`, défini par l'observation, le rend explicite. Précision attendue : « à la clôture » ou « après observation ».

### T-04 — m — certain — Réserve à sept attributs : le glossaire est aligné, mais le test de sortie canonique d'ACTION en garde six
- **A** `V1/official/GLOSSAIRE.md:59` : « il porte une réserve complète (owner, portée, date ou version, impact, prochaine preuve, date de revue, condition de sortie) ».
- **B** `V1/official/ACTION.md:1021` (`ACTION/CLOSE-EXIT-CHECK`, question 7) : « La réserve, si elle existe, possède-t-elle owner, périmètre, impact, date de revue, prochaine preuve et condition de sortie ? » Même liste à six dans `ACTION.md:1003` (ligne « Réserves »).
- **Conflit.** Il ne s'agit pas d'une régression : les deux lignes d'ACTION sont antérieures. Mais Q-10 n'est résolu que dans la façade. Le propriétaire (`ACTION.md:482-494`, `RESERVATION_FIELDS`) et le glossaire exigent désormais sept attributs, alors que le test de sortie canonique d'ACTION n'en vérifie que six (sans `DATE / VERSION`). LCF-40 contrôle uniquement la ligne du glossaire.

## Constat visé → corrigé

| Constat R.02 | Hunk(s) | Corrigé | Justification |
|---|---|---|---|
| Q-01 droits inconnus, portée machine | `ACTION.md:667`, `CHANGELOG.md:16` | **oui** | Le texte borne le contrôle machine à `DIRECTION`, où `rights_status` est requis. Conforme à `validate_run_card.py:319` et `:411-412`, et aux cas B2-10a/b. Q-11 (tension avec `ACTION.md:500`), non visé, subsiste sans aggravation. |
| Q-02 paquet SYSTÈME | `ACTION.md:466` | **oui** | Les cinq paquets portent la triade (LCF-37). L'exigence rejoint `validate_run_card.py:322`, dans `check_accepted`. `CHANGELOG.md:12` devient exact. Remarque : la colonne machine de la ligne SYSTÈME ne nomme que `closure.system_package`, alors que `decision_change` est aussi contrôlé ; c'est le même type d'écart que Q-04, non visé. |
| Q-03 copies SAVOIR de la triade | `SAVOIR.md:30`, `:879` | **oui** | Les deux lignes nomment `N/A-JUSTIFIED` et `NOT-OBSERVED` et passent LCF-38. Reste un défaut de phase à `:30` (T-03). |
| Q-05 exemple QUICKSTART §9 | `QUICKSTART.md:230`, `:252`, `:256` | **partiel** | Corrigés : `CHANGE:` retiré, état `CHECKING` compatible avec le champ, valeur prise dans la triade. Reste la recomposition non observée présentée comme acquise (T-01). |
| Q-06 QUICKSTART §5 chargement | `QUICKSTART.md:153-154` | **oui** | Aligné sur `ACTION.md:16-17` et `SKILL.md:95-96` (LCF-39). `DIRECTION/DAILY` (`DIRECTION.md:255-256`) reste sans gates, écart déjà qualifié de plus faible dans Q-06. |
| Q-10 réserve à sept attributs | `GLOSSAIRE.md:59` | **oui** pour la ligne visée ; **partiel** pour le package | Conforme au schéma (:210) et à `RESERVATION_FIELDS`. Le test de sortie d'ACTION reste à six attributs (T-04). |
| O-1 `null` admis | `ACTION.md:386`, `machine_projection.md:120`, `CHANGELOG.md:16` | **oui** pour la liste ; **partiel** pour la règle d'omission | La liste des trois champs est exacte contre le schéma, et les exemples JSON et YAML n'utilisent `null` que sur ces champs. La clause d'omission est trop large (T-02). |
| Décompte des conditions de façade | `RELEASE_NOTES.md:18`, `CHANGELOG.md:17` | **oui** | 42 entrées dans `check_facades`. Le passage de 21 à 42 est cohérent avec `CHANGELOG.md:27`, qui donne 21 pour V1.1.0. |

Constats de R.02 non visés par ce diff et non réexaminés : Q-04, Q-07, Q-08, Q-09, Q-11, Q-12, Q-13.

**Bloquants : 0 ; significatifs : 1 ; mineurs : 3**
