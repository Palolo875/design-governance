# Classement en aveugle — palettes P1 à P6

Source lue : `mesure/palettes_anonymes.txt` uniquement. Teinte (H), saturation (S) et luminance (L) calculées en HSL avec Python. Une couleur est traitée comme « état » quand elle a un fond pâle apparié et une teinte rouge, vert ou ambre.

| Palette | Classe | Confiance | Justification |
|---|---|---|---|
| P1 | neutres + un accent | moyenne | Les surfaces sont des blancs et gris cassés, et une seule teinte, le bleu marine #2C3E91 (H≈229°, présent 3 fois), porte les actions. Le rouge, l'ambre et le vert sont des états. Le rouille #9A3412 et le violet #4A3F9E, chacun avec son fond pâle, ressemblent à des badges ou à des états secondaires, ce qui laisse une petite part d'incertitude. |
| P2 | sombre + doré | haute | Les fonds sont presque noirs (#121212, #1C1B1A) et l'accent principal est un orange doré (#FF8A1F/#FFA24D, H≈28°), prolongé par des ors (#FFC53D, #FFD27A). Le vert #9BE15D et le rouge #FF5A4E sont des états. |
| P3 | multicolore | basse | Sur un fond beige et un quasi-noir très présent (#141312), trois teintes saturées cohabitent : l'orange vermillon #FF4F14 et ses nuances, le jaune #F2C200 (présent 2 fois) et le sarcelle #3E9A8F. Aucun rouge d'erreur classique n'apparaît, ce qui suggère que le jaune fait partie de l'identité et n'est pas un simple état. Lecture alternative plausible : neutres + un accent orange, le jaune et le sarcelle servant alors d'états. |
| P4 | neutres + un accent | haute | Ce sont des gris froids classiques avec un seul accent bleu (#1D4ED8, #1E40AF au survol, #2563EB) et un jeu complet d'états : vert, ambre, rouge, ainsi qu'un violet d'info ou de badge avec son fond pâle. |
| P5 | neutres + un accent | moyenne | Neutres chauds (beiges, bruns-noirs #2A2426/#453C3F) avec une seule teinte d'identité, le bordeaux #7A1F2B. Le rouge, l'ambre et le vert sont des états. Les bleus #2F5A7A (avec fond) et #0B57D0 ressemblent à de l'info, des liens ou du focus, mais ils pourraient aussi faire office de second accent. |
| P6 | neutres + un accent | haute | Neutres chauds avec un bleu profond unique pour les actions (#1F4E79, #173C5E au survol, texte blanc dessus), décliné en #2F6690/#3B82C4 pour l'info et le focus. Le bordeaux, le vert, l'ambre et l'orange ont chacun leur fond pâle, ce sont des états. |

Bilan : 4 « neutres + un accent » (P1, P4, P5, P6), 1 « sombre + doré » (P2), 1 « multicolore » (P3, le cas le plus ambigu).
