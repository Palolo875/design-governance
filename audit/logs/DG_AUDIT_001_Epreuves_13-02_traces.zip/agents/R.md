# R — Revue bornée des contradictions V1.0.0 → V1.1.0

**Périmètre lu :** `revue/diff_phase12_textes.diff` et `revue/pkg/` seulement. Chaque ligne ajoutée du diff a été confrontée à ses voisins dans le package par grep : textes, schéma `run_card`, validateurs.
**Légende.** Gravité : **B** = bloquant, **S** = significatif, **m** = mineur. Certitude : **certain** quand les deux textes se contredisent littéralement ; **probable** quand le conflit dépend d'une lecture raisonnable.
Les numéros de ligne renvoient au package complet (`pkg/…`).

---

## 1. Bloquants

### R-01 — `N/A-JUSTIFIED` et `NOT-OBSERVED` : le propriétaire se contredit sur la conséquence décisionnelle. B, certain
- **A :** `ACTION.md:168` (ajouté). « `NOT-OBSERVED` (conséquence attendue absente ; interdit `ACCEPTED`) ». Voir aussi `ACTION.md:243` et `DIRECTION.md:235`.
- **B :** `ACTION.md:295` (non modifié, table `RUN_CARD`). « `DECISION-CHANGE` […] ; `N/A-JUSTIFIED` si aucune conséquence n'est obtenue **ou attendue** ». Même formule dans `GLOSSAIRE.md:38`.
- **Conflit :** pour une conséquence attendue mais non obtenue, B prescrit `N/A-JUSTIFIED`, qui reste compatible avec `ACCEPTED`. A prescrit `NOT-OBSERVED`, qui interdit `ACCEPTED`. La triade, présentée comme un changement phare de V1.1.0 (`CHANGELOG.md:14`), est donc contournable depuis la table canonique elle-même.

### R-02 — B1b « hors scope, il ne s'applique pas » alors que la machine l'exige toujours. B, certain
- **A :** `ACTION.md:786`. B1b est requis quand le risque V/craft domine ou quand le verdict V repose sur une intention non confrontée. `ACTION.md:800` : « Hors de son scope, il ne s'applique pas. »
- **B :** `ACTION.md:798` (ajouté) et `validate_run_card.py:369-391`. `closure.b1b` est exigé pour **toute** surface `DIRECTION` acceptée avec V en `PASS` ou `PASS-WITH-RESERVATION`. Or `N/A-JUSTIFIED` n'admet que `no_editable_decision` ou `equivalent_pair_valid`.
- **Conflit :** un run `DIRECTION` accepté hors du scope de B1b ne peut pas être sérialisé honnêtement. Aucun motif « hors scope » n'est recevable, ce qui pousse à déclarer un motif faux.

## 2. Significatifs

### R-03 — Creative Boot : les façades gardent les quotas supprimés par le propriétaire. S, certain
- **Propriétaire :** `DIRECTION.md:174-175`. « ANTI-DIRECTIONS: patterns visuels concrets » (le « deux » a été retiré) ; « STRUCTURAL-TENSION: … un ou deux ». Voir aussi `BIBLIOTHEQUE.md:90`.
- **Façades non alignées :** `QUICKSTART.md:45` et `SKILL.md:119` disent encore « deux anti-directions concrètes, **une** tension ».
- Cela contredit aussi la ligne « Façades … alignés sur leurs propriétaires » de `CHANGELOG.md:15` et `RELEASE_NOTES.md`.

### R-04 — Ligne de run et mémoire de lancement : `OWNER` et `SCOPE` « jamais omis », mais absents de la ligne affichée. S, certain
- **A :** `DIRECTION.md:161` (ajouté). « `OWNER` et `SCOPE` ne sont jamais omis ».
- **A bis :** `DIRECTION.md:239` (ajouté). La ligne compacte de la sortie immédiate serait « l'affichage » de la mémoire de lancement : `ID, MODE, DECISION, RISK, SCOPE, ARTIFACT, OWNER, NEXT-PROOF, LIMIT, EXIT-CONDITION`.
- **B :** `DIRECTION.md:223`, qui est cette ligne compacte : `RUN — ID — MODE — décision — risque — preuve suivante — état`. Elle n'a ni SCOPE, ni OWNER, ni ARTIFACT, ni LIMIT, ni EXIT-CONDITION, et elle contient `STATE`.
- **Mêmes lignes dans les façades :** `QUICKSTART.md:76` et `SKILL.md:83` donnent `ID — MODE — DECISION — RISK — NEXT-PROOF — STATE`.
- Autre point : la mémoire « sous-ensemble de lancement de ce handoff » (`ACTION.md:37`) contient `ID`, qui ne figure pas dans le handoff.

### R-05 — Forme courte LITE : `OWNER` passe `N/A-JUSTIFIED` par défaut. S, probable
- **A :** `ACTION.md:37` (ajouté). Hors paquet LITE, les champs du handoff sont « `N/A-JUSTIFIED` par défaut, avec deux pertes déclarées (METHOD, EXIT-CONDITION) ». Le paquet LITE (`ACTION.md:461`) ne contient pas `OWNER`.
- **B :** `DIRECTION.md:161` (« OWNER et SCOPE ne sont jamais omis ») et `DIRECTION.md:274` (FAST-PATH : « Un risque principal et son owner », ajouté).
- **Conflit :** l'owner devient `N/A` par défaut en LITE. Le décompte « deux pertes » est lui aussi incohérent, puisque SCOPE, OWNER, LIMIT et NEXT-PROOF passent également à `N/A`.

### R-06 — Skill : réponse visible par défaut, puis handoff comme sortie attendue. S, certain
- **A :** `SKILL.md:81` (ajouté). « Par défaut, restitue la réponse visible ». Cohérent avec `ACTION.md:39-41` : réponse visible par défaut, handoff « pour une reprise ou un run persistant ».
- **B :** `SKILL.md:153` (ajouté). « Livrer d'abord l'artefact ou le diff. Donner ensuite le handoff au niveau du mode ».
- **Conflit :** la skill contredit son propre défaut et celui du propriétaire.

### R-07 — Skill : gates B « non chargés par défaut » en LITE et ITER. S, certain
- **A :** `ACTION.md:18` (ajouté). En LITE, charger « `ACTION/GATE-A` applicable et `ACTION/GATE-B` du risque dominant ». `ACTION.md:221-222` et `ACTION.md:407` exigent une preuve B en LITE et le Gate B du risque touché en ITER.
- **B :** `SKILL.md:95-96`. En LITE et ITER, « Non chargé par défaut : … gates B/C ».
- **Autres écarts :** le socle `ACTION/STATUS` et `ACTION/PRECONDITION`, commun à tous les modes (`ACTION.md:16`), est absent des tables de charge de la skill et de `QUICKSTART.md` §5 (m). Dans ACTION lui-même, la ligne ITER de la carte (`ACTION.md:19`) omet Gate A et Gate B, que `ACTION.md:222` exige (m, probable).

### R-08 — Table de correspondance : champs attribués à `VISUAL_TARGET` qui n'y existent pas. S, certain
- **A :** `ACTION.md:323` (ajouté). « VISUAL_TARGET : thèse, anti-direction, **premier objet, périmètre, contrainte** → `direction.thesis`, `.anti_direction`, `.first_object`, `.scope`, `.constraint` ».
- **B :** `DIRECTION.md:382-394`. La table de `VISUAL_TARGET` n'a ni premier objet, ni périmètre, ni contrainte. `DIRECTION.md:396` (ajouté) : « Cette table est la seule représentation canonique de la cible ». Ces champs viennent en réalité de `DIRECTION/START` (Entrée minimale) et de `CREATIVE-BOOT`.
- **Renvoi du même type :** « Paquet d'alternative (`DIRECTION/VISUAL_TARGET`) » (`ACTION.md:328`). Le paquet est défini dans `DIRECTION` §1 (`DIRECTION.md:698`) et l'ABSOLU 3 (`DIRECTION.md:595`), pas dans `VISUAL_TARGET` (m, certain).

### R-09 — Phase de `NEXT-PROOF` contradictoire dans la même table. S, certain
- **A :** `ACTION.md:319`. « NEXT-PROOF | clôture ».
- **B :** `ACTION.md:324`, dans la même table. « objet de preuve | avant build → … | `next_proof` avant ». S'y ajoutent `DIRECTION.md:157` (NEXT-PROOF dans l'entrée minimale avant construction) et le schéma, qui exige `next_proof` à tout état.
- **Même problème (m) :** `PROOF / TRACE-LOCATOR | clôture`, alors que le schéma exige `trace_locator` dès `INTAKE` pour ITER, STANDARD, SYSTÈME et DIRECTION (`run_card.schema.json`, `allOf`).

### R-10 — `machine_projection.md` contredit le schéma sur les axes et `profile_decision`. S, certain
- **A :** `machine_projection.md:120` (non modifié). « Utiliser `PASS`, `PASS-WITH-RESERVATION`, `NOT-VERIFIED`, **`NOT-OBSERVED`** et `N/A-JUSTIFIED` pour les axes, les contrôles ou les limites ».
- **B :** l'enum `axes` du schéma et `ACTION.md:195-198` (`PASS`, `PASS-WITH-RESERVATION`, `RETURN`, `N/A-JUSTIFIED`, `NOT-VERIFIED`). `ACTION.md:127` (ajouté) : « `NOT-OBSERVED` n'y est pas employé : il qualifie une conséquence de décision ». `RETURN` manque aussi dans la façade.
- **A2 :** `machine_projection.md:122`. `profile_decision` : « ses **quatre** champs sont obligatoires ».
- **B2 :** le schéma en exige cinq (`phase` en plus). L'exemple ajouté (`machine_projection.md:86`) porte d'ailleurs `phase`.
- **Propriétaire muet :** `ACTION` ne définit nulle part `profile_decision.phase` (`intended` / `observed`), ni la règle du validateur « un verdict accepté exige phase `observed` » (`validate_run_card.py:329`). Le champ n'existe que dans le schéma et les façades.

### R-11 — `NOT-OBSERVED` employé pour une preuve ou une dimension non observée. S, probable
- **Propriétaire :** `ACTION.md:127` et `ACTION.md:168` (ajoutés). `NOT-OBSERVED` qualifie une conséquence de décision, « à ne pas confondre avec `NOT-VERIFIED`, qui qualifie une preuve manquante ».
- **Contradictions :**
  - `DIRECTION.md:329` (ajouté) : pour une dimension du premier objet non observée, « `NOT-OBSERVED` lorsqu'une conséquence attendue n'a pas été observée ». Or `DIRECTION.md:517` dit : « Sans capture inspectée, la qualité perceptuelle reste `NOT-VERIFIED` ».
  - `QUICKSTART.md:296` : « la preuve attendue est obtenue ou déclarée `NOT-VERIFIED`, `NOT-OBSERVED` ou `N/A-JUSTIFIED` ».
  - `GLOSSAIRE.md:42` : « une conséquence, un changement **ou un résultat** », définition plus large.

### R-12 — Droits inconnus : « pas d'`ACCEPTED` » ou retour/escalade ? S, probable
- **A :** `ACTION.md:499` (ajouté). « en cas de doute (`unknown`), pas d'`ACCEPTED` ». Le validateur (`validate_run_card.py:319`) ne bloque que `ACCEPTED`, donc `ACCEPTED-WITH-RESERVATION` passe.
- **B :** `ACTION.md:666` (non modifié). « Un droit inconnu ou non autorisé déclenche `RETURNED`, `ESCALATED` ou le statut prévu ». `ACTION.md:499`, première phrase : la sortie « ne devient pas acceptable par simple mention ».
- **Conflit :** une diffusion acceptée avec réserve reste possible avec des droits inconnus.

### R-13 — Ressource technique : sept champs dans ACTION, une autre liste dans SAVOIR. S, certain
- **A :** `ACTION.md:943-957` (ajouté). Une nouvelle dépendance exige « les sept champs ci-dessous » : stack et version, date, capacité, fallback, limites, owner, prochaine revue.
- **B :** `SAVOIR.md:780` (modifié), qui renvoie aux « champs de la politique d'`ACTION/POLICIES` ». La ligne suivante, `SAVOIR.md:782` (non modifiée), donne une autre liste : « … claims applicables et capacité résolue », avec « claims applicables » et sans « prochaine revue ».

### R-14 — « Sortie définie une seule fois par `CLOSE-PACKAGE` » : faux dans ACTION même. S, certain
- **A :** `ACTION.md:24` (ajouté). « La sortie à conserver de chaque mode est définie une seule fois, par `ACTION/CLOSE-PACKAGE` ».
- **B :** les blocs `RUN-*` gardent chacun leur **Sortie**, qui diverge du paquet. Exemples :
  - `ACTION.md:409` (RUN-LITE, sans « risque ») face à `ACTION.md:461` ;
  - `ACTION.md:449` (RUN-SYSTEM : « plan de migration », sans impact ni consumers) face à la ligne SYSTÈME du paquet.

### R-15 — Revue créative « unique » ou double ? S, probable
- **A :** `SAVOIR.md:232` (CFT-00, Creative Quality Review). Revue « après la première scène **et après la repasse** de craft ».
- **B :** `ACTION.md:581` (ajouté) : une revue, puis une repasse. `DIRECTION.md:480` (ajouté) : « la revue créative unique ». `ACTION.md:870` (ajouté) : Gate C « ne refait pas une seconde revue ».
- **Lecture en cause :** si « unique » veut dire « une seule définition », il n'y a pas de conflit. S'il veut dire « une seule occurrence », il y en a un.

## 3. Mineurs

- **R-16 — Protection de niveau, absolue ou conditionnelle ?** m, probable. `ACTION.md:303` (ajouté) et le validateur : « Un risque critique exclut `LITE` et `ITER` ». `DIRECTION.md:142` (START, propriétaire) : l'exclusion vaut « dès que le changement touche » le risque, et LITE ou ITER « restent possibles » si le delta est démontré strictement local.
- **R-17 — Vocabulaire B1b différent de `decision_change` pour la même notion.** m, certain. `closure.b1b.pair.outcome` = `confirmed` / **`modified`** / `abandoned` (`ACTION.md:798`). `decision_change.outcome` = `CONFIRMED` / **`CHANGED`** / `ABANDONED` (`ACTION.md:168`).
- **R-18 — « triade » désigne un ensemble de cinq valeurs.** m, certain. `ACTION.md:243` (« `outcome` porte la triade ») et `CHANGELOG.md:14` parlent de triade ; l'enum `outcome` a cinq valeurs (`ACTION.md:168`). `DIRECTION.md:235` utilise « triade » pour le repli `N/A` / `NOT-OBSERVED`. Le terme n'est défini nulle part.
- **R-19 — Table de correspondance incomplète pour `decision_change`.** m, certain. `ACTION.md:318` donne `decision_change (outcome, reason)`. Le schéma exige `outcome`, `value` et `evidence` ; `reason` n'est exigé que pour `N/A`.
- **R-20 — `direction.calibration` écrit comme une valeur.** m, certain. `ACTION.md:551` et `DIRECTION.md:441` : « `direction.calibration` : `real_constraint` … ». Le schéma en fait un objet `{basis, detail}` avec quatre bases, dont `observed_anchor` et `provided_anchor`.
- **R-21 — « Une ancre `transformed` … requise pour l'acceptation » sans restriction de mode.** m, probable. `ACTION.md:166`. Le validateur ne l'applique qu'en DIRECTION, et des exemples acceptés LITE ou STANDARD n'ont pas d'ancre. Le terme exact du schéma est `transformation_status: transformed`.
- **R-22 — Réserve décrite avec six attributs au lieu de sept.** m, certain. `GLOSSAIRE.md:59` (exemple CLOSED, ajouté) omet `DATE / VERSION`, que `ACTION.md:483-491` compte parmi les sept attributs.
- **R-23 — `DECISION-CHANGE` : `CHANGED` illustré par une décision « abandonnée ».** m, probable. `GLOSSAIRE.md:57` (ajouté). Ambigu face à `ABANDONED`.
- **R-24 — Exemple SYSTÈME : `ABANDONED` avec `ISSUE: RETURNED`.** m, probable. `examples.md` (bloc SYSTÈME, ajouté) : « abandonnée jusqu'à correction ». `RETURNED` signifie reprendre dans le même mode, ce qui ressemble plus à un report qu'à un abandon.
- **R-25 — Libellés de façade périmés.**
  - m, certain. `SKILL.md:75` : « `ACTION/STRUCTURED-PROOF` organise les contrats **avant build** ». Le titre est devenu « contrats de décision et leur preuve », avec une règle de phase (`ACTION.md:595-611`).
  - m, certain. `README.md:25` : « Le parcours **minimal** est : Classer → … → fermer ». `QUICKSTART.md:85` (ajouté) l'appelle désormais parcours **complet**, dont chaque mode ne garde qu'une partie.
- **R-26 — Chargement de `BIBLIOTHEQUE/COMPONENTS` en SYSTÈME incohérent.** m, certain. Le propriétaire `DIRECTION.md:259` (DAILY) le charge « si la bibliothèque change réellement ». `QUICKSTART.md` §5 dit « si un composant change ». `SKILL.md:99` et `ORCHESTRATION_MAP.md` (noyau, ligne modifiée) le chargent sans condition.
- **R-27 — Lecteur de routes décrit de deux façons.** m, certain. `QUICKSTART.md:118` : le lecteur « résout le locator dans `READING_MAP.md`, vérifie le titre exact ». `READING_MAP.md:97` (ajouté) décrit trois étapes, dont préfixe + titre qui commence par le locator, puis sous-locator.
- **R-28 — Locators numériques périmés dans le validateur.** m, certain. `validate_run_card.py:220` cite « DIRECTION 140 » (la Protection de niveau est à la ligne 142). La ligne 422 cite « ACTION 483 » (la règle sur l'ancre manquante est à `ACTION.md:551`). La ligne 501 cite « DIRECTION 672 » (« ITER se souvient » est à la ligne 654). Dans `validate_reading_map.py:265`, LCF-08 attribue « OWNER et SCOPE jamais omis » à `ACTION/RUN_CARD`, alors que la règle est dans `DIRECTION/START` et que la table `RUN_CARD` n'a pas de champ SCOPE.
- **R-29 — « Zéro contrat est valide » face à « au moins un contrat ».** m, probable. `ACTION.md:597` (ajouté) et `RELEASE_NOTES` (« objets facultatifs »). `validate_contracts.py:265` : « production_contracts exige au moins un contrat ». C'est cohérent seulement si « zéro contrat » veut dire « aucun fichier ».
- **R-30 — Règle « aucun glissement dans un champ voisin » contredite par la même table.** m, probable. `ACTION.md:333` (ajouté). La même table projette NEXT-ACTION dans `creative_close.next_polish_action` ou dans `next_proof` (`ACTION.md:320`).
- **R-31 — SAVOIR généralise la règle de START.** m, probable. `SAVOIR.md:696` (ajouté) : « sinon la direction est traitée d'abord ». `DIRECTION.md:140` limite cela au cas où le changement partagé découle d'une décision de direction.
- **R-32 — Ancre requise ou absence déclarée ?** m, probable. `SAVOIR.md:477` (ajouté) : « l'ancre est requise (ABSOLU 2) ». `SAVOIR.md:917` (ajouté) : « l'ancre suit `VISUAL_TARGET` (utile, **ou absence déclarée**) ».

## 4. Zones vérifiées sans contradiction trouvée

- **Versions et dates :** V1.1.0 et 2026-09-26 sont cohérents entre README, RELEASE_NOTES, CHANGELOG, QUICKSTART, le README officiel, l'export Local et le manifeste (`version: 1.1.0`).
- **Cycle de vie `SEED` :** les listes de statuts de `BIBLIOTHEQUE.md:63` et `:789` correspondent à la table du `CHANGELOG`. Les transitions SEED, PILOT et DEPRECATED sont cohérentes.
- **Protection critique, réserve, exception, reclassement, paquet SYSTÈME, `rights_status` (DIRECTION seulement), `identity_stake` :** ACTION, schéma, validateur et `machine_projection` concordent.
- **« 21 conditions de façade » :** le compte est exact dans `validate_reading_map.py`. Les identifiants sautent de LCF-17 à LCF-20, ce qui est sans effet.
- **Colonne CFT-00 du premier objet :** elle est conforme à la table de `SAVOIR.md` CFT-00, avec la perte déclarée « Culture visuelle ». Les huit dimensions de QUICKSTART §6 suivent l'ordre et les noms de DIRECTION.
- **Ordre VISUAL_TARGET → FIRST-OBJECT :** il est cohérent entre l'architecture d'activation, la chaîne de lecture, RUN-PRIORITY, READING_MAP, ORCHESTRATION_MAP et la skill.
- **Locators ajoutés :** ils résolvent tous dans le package (`SAVOIR/CRAFT/CFT-00` et `/CFT-01` et `/CFT-03`, `ACTION/GATE-B/B1b`, `BIBLIOTHEQUE/TENSION`, `ACTION/AUTHORITY`, `ACTION/POLICIES`, `ACTION/OVERRIDE`, `DIRECTION/START/TREE`). Aucun renvoi ne vise les titres supprimés (tests compacts de DOUBLE-LOOP, « trois niveaux de preuve », « Entrée prioritaire » de DIRECTION).
- **`build_distributions.sh` :** aucune contradiction textuelle. La réécriture des chemins Local couvre bien les nouveaux chemins `skills/…/references/*.md` de QUICKSTART.
- **Bloc « Ce qu'atteste une `RUN_CARD` validée » :** copie identique dans ACTION, README et `machine_projection`.
