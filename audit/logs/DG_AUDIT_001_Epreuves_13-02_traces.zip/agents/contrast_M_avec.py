def lin(c):
    c=c/255
    return c/12.92 if c<=0.04045 else ((c+0.055)/1.055)**2.4
def L(h):
    h=h.lstrip('#'); r,g,b=(int(h[i:i+2],16) for i in (0,2,4))
    return 0.2126*lin(r)+0.7152*lin(g)+0.0722*lin(b)
def cr(a,b):
    x,y=sorted([L(a),L(b)],reverse=True); return (x+0.05)/(y+0.05)
P={
1:[("text/primary sur surface/base","#231A1C","#FBF8F6",4.5),
   ("text/secondary sur surface/base","#5E5256","#FBF8F6",4.5),
   ("text/secondary sur surface/sunken","#5E5256","#F2ECE8",4.5),
   ("text/on-action sur action/primary","#FFFFFF","#7A1F2B",4.5),
   ("action/primary (lien) sur surface/base","#7A1F2B","#FBF8F6",4.5),
   ("action/primary-hover texte blanc","#FFFFFF","#611823",4.5),
   ("state/eligible fg sur bg","#1D6A43","#E6F2EB",4.5),
   ("state/deferred fg sur bg","#7A4E00","#FBF0D9",4.5),
   ("state/ineligible fg sur bg","#4A4346","#ECE8E9",4.5),
   ("state/critical fg sur bg","#A62C14","#FCE9E2",4.5),
   ("state/critical fg sur surface/raised","#A62C14","#FFFFFF",4.5),
   ("border/control sur surface/base","#8C7F83","#FBF8F6",3.0),
   ("focus/ring sur surface/base","#0B57A4","#FBF8F6",3.0),
   ("focus/ring vs action/primary (adjacent)","#0B57A4","#7A1F2B",1.0),
   ("action/primary vs state/critical fg (distinction, info)","#7A1F2B","#A62C14",1.0)],
2:[("text/primary sur surface/concrete","#121212","#D8D5CE",4.5),
   ("text/secondary sur surface/concrete","#3D3B37","#D8D5CE",4.5),
   ("text/primary sur surface/poster","#121212","#ECEAE4",4.5),
   ("text/on-action sur action/minium","#121212","#D9401A",4.5),
   ("text/on-action sur action/minium-hover","#121212","#F0633B",4.5),
   ("action/minium vs surface/concrete (composant)","#D9401A","#D8D5CE",3.0),
   ("text/primary sur signal/yellow","#121212","#F2C300",4.5),
   ("signal/yellow sur state/soldout-ink","#F2C300","#121212",4.5),
   ("border/control sur surface/concrete","#5A5750","#D8D5CE",3.0),
   ("focus/ring ink sur surface/concrete","#121212","#D8D5CE",3.0),
   ("night text/primary sur night surface","#E4E1DA","#161614",4.5),
   ("night text/secondary sur night surface","#A9A59C","#161614",4.5),
   ("night text/primary sur night raised","#E4E1DA","#22211E",4.5),
   ("night text/on-action sur night minium","#121212","#F05A2E",4.5),
   ("night signal/yellow texte sur night surface","#F2C300","#161614",4.5),
   ("night border/control sur night surface","#7A766D","#161614",3.0),
   ("night focus/ring sur night surface","#E4E1DA","#161614",3.0)],
3:[("text/primary sur surface/table","#1A1C1F","#FFFFFF",4.5),
   ("text/secondary sur surface/table","#5B6068","#FFFFFF",4.5),
   ("text/secondary sur surface/row-alt","#5B6068","#F6F6F4",4.5),
   ("text/primary sur surface/chrome","#1A1C1F","#EFEFEC",4.5),
   ("text/secondary sur surface/chrome","#5B6068","#EFEFEC",4.5),
   ("text/primary sur surface/row-selected","#1A1C1F","#E6ECFA",4.5),
   ("text/on-action sur action/primary","#FFFFFF","#1F46B8",4.5),
   ("action/primary (lien) sur surface/table","#1F46B8","#FFFFFF",4.5),
   ("state/matched glyph sur surface/table","#2E6B45","#FFFFFF",3.0),
   ("state/gap fg sur state/gap bg","#7A4A00","#FFF1D6",4.5),
   ("state/gap edge sur surface/table","#B7791F","#FFFFFF",3.0),
   ("state/blocking fg sur state/blocking bg","#A4261B","#FDE7E4",4.5),
   ("state/blocking edge sur surface/table","#C2382B","#FFFFFF",3.0),
   ("state/proposed fg sur surface/table","#5B3FA8","#FFFFFF",4.5),
   ("state/proposed border sur surface/table","#7B61C4","#FFFFFF",3.0),
   ("text/primary sur state/gap bg","#1A1C1F","#FFF1D6",4.5),
   ("text/primary sur state/blocking bg","#1A1C1F","#FDE7E4",4.5),
   ("border/control sur surface/table","#8A8F96","#FFFFFF",3.0),
   ("focus/ring sur surface/table","#1F46B8","#FFFFFF",3.0)]}
for k,v in P.items():
    print(f"## brief {k}")
    for n,f,b,t in v:
        c=cr(f,b); s="PASS" if c>=t else "FAIL"
        if t==1.0: s="INFO"
        print(f"| {n} | {f} / {b} | {c:.2f}:1 | seuil {t if t>1 else '-'} | {s} |")
