# Palettes d'interface — trois briefs

## Brief 1 — Suivi des dons de sang (hôpital régional, donneurs et infirmiers)

Justification : un blanc cassé chaud et un bleu encre posé disent « soin fiable » sans froideur clinique. Le rouge sang reste une couleur d'identité, réservée aux groupes sanguins et au don. Les actions passent par le bleu, et l'erreur prend un vermillon orangé distinct, pour qu'un infirmier ne confonde jamais « donneur O− » et « champ invalide ».

```json
{"brief": 1, "palette": [
  {"role": "surface-fond", "hex": "#FAF7F5"},
  {"role": "surface-carte", "hex": "#FFFFFF"},
  {"role": "surface-atténuée (zones infirmier, en-têtes de liste)", "hex": "#F1ECE8"},
  {"role": "texte-principal", "hex": "#1E1B1A"},
  {"role": "texte-secondaire", "hex": "#5C5552"},
  {"role": "texte-désactivé", "hex": "#9A918D"},
  {"role": "action-primaire", "hex": "#1F4E79"},
  {"role": "action-primaire-survol", "hex": "#173C5E"},
  {"role": "texte-sur-action", "hex": "#FFFFFF"},
  {"role": "accent-identité-sang (groupes sanguins, jauge de don)", "hex": "#8A1C2B"},
  {"role": "accent-identité-sang-fond", "hex": "#F6E4E6"},
  {"role": "état-succès (don validé, éligible)", "hex": "#2E7D4F"},
  {"role": "état-succès-fond", "hex": "#E3F1E8"},
  {"role": "état-avertissement (délai entre dons, stock bas)", "hex": "#A15C07"},
  {"role": "état-avertissement-fond", "hex": "#FBEFD9"},
  {"role": "état-erreur (inéligible, saisie invalide)", "hex": "#C2410C"},
  {"role": "état-erreur-fond", "hex": "#FDEBE2"},
  {"role": "état-info", "hex": "#2F6690"},
  {"role": "frontière-subtile", "hex": "#E4DDD8"},
  {"role": "frontière-forte (champs de saisie)", "hex": "#B8AEA8"},
  {"role": "anneau-focus", "hex": "#3B82C4"}
]}
```

## Brief 2 — Festival de musique électronique itinérant en friches industrielles

Justification : on part du lieu plutôt que du cliché néon. Le fond reprend le béton nocturne, l'accent l'orange sodium des lampadaires d'usine, et un vert « signal de sécurité » sert de contre-point. La rouille et l'acier donnent les nuances intermédiaires, si bien que tout semble venir de la friche.

```json
{"brief": 2, "palette": [
  {"role": "surface-fond (béton nuit)", "hex": "#121212"},
  {"role": "surface-élevée (cartes, lineup)", "hex": "#1C1B1A"},
  {"role": "surface-contraste (sections claires, billetterie)", "hex": "#E6E1D8"},
  {"role": "texte-principal", "hex": "#EDEAE4"},
  {"role": "texte-secondaire", "hex": "#A39E96"},
  {"role": "texte-sur-surface-claire", "hex": "#161514"},
  {"role": "action-primaire (billets, CTA)", "hex": "#FF8A1F"},
  {"role": "action-primaire-survol", "hex": "#FFA24D"},
  {"role": "texte-sur-action", "hex": "#121212"},
  {"role": "action-secondaire (liens, filtres de date)", "hex": "#C9C3B8"},
  {"role": "accent-signal (nouvelle étape, live)", "hex": "#9BE15D"},
  {"role": "accent-rouille (étiquettes de lieu, décor)", "hex": "#8C3B1E"},
  {"role": "état-succès (billet confirmé)", "hex": "#9BE15D"},
  {"role": "état-avertissement (derniers billets)", "hex": "#FFC53D"},
  {"role": "état-erreur (complet, paiement refusé)", "hex": "#FF5A4E"},
  {"role": "frontière-subtile (acier)", "hex": "#2E2C2A"},
  {"role": "frontière-forte", "hex": "#4A4744"},
  {"role": "anneau-focus", "hex": "#FFD27A"}
]}
```

## Brief 3 — Outil B2B de réconciliation comptable pour PME (tableaux denses, écarts)

Justification : sur des tableaux denses, la couleur doit porter une information, pas décorer. Les neutres froids restent très discrets et le bleu marine est la seule couleur d'action. Les états suivent le travail du comptable : rapproché en vert sourd, écart à traiter en ambre, anomalie bloquante en rouge. Chacun a un fond de ligne pâle pour rester lisible sur des centaines de lignes.

```json
{"brief": 3, "palette": [
  {"role": "surface-fond (app)", "hex": "#F5F6F8"},
  {"role": "surface-tableau", "hex": "#FFFFFF"},
  {"role": "surface-ligne-alternée", "hex": "#FAFBFC"},
  {"role": "surface-en-tête-tableau", "hex": "#EEF0F3"},
  {"role": "surface-ligne-sélectionnée", "hex": "#E6EEFA"},
  {"role": "texte-principal (montants, libellés)", "hex": "#16191D"},
  {"role": "texte-secondaire (dates, références)", "hex": "#5B6470"},
  {"role": "texte-désactivé", "hex": "#9AA2AD"},
  {"role": "action-primaire (rapprocher, valider)", "hex": "#1D4ED8"},
  {"role": "action-primaire-survol", "hex": "#1E40AF"},
  {"role": "texte-sur-action", "hex": "#FFFFFF"},
  {"role": "action-secondaire (bordure/texte bouton neutre)", "hex": "#374151"},
  {"role": "état-rapproché (texte/icône)", "hex": "#3F7D58"},
  {"role": "état-rapproché-fond", "hex": "#EAF4EE"},
  {"role": "état-écart-à-traiter (texte/icône)", "hex": "#9A5B00"},
  {"role": "état-écart-à-traiter-fond", "hex": "#FFF4DC"},
  {"role": "état-anomalie-bloquante (texte/icône)", "hex": "#B42318"},
  {"role": "état-anomalie-bloquante-fond", "hex": "#FDECEA"},
  {"role": "état-suggestion-auto (correspondance proposée)", "hex": "#6941C6"},
  {"role": "état-suggestion-auto-fond", "hex": "#F2EEFB"},
  {"role": "montant-négatif", "hex": "#B42318"},
  {"role": "frontière-cellule", "hex": "#E3E6EA"},
  {"role": "frontière-forte (séparateurs de groupes, champs)", "hex": "#C5CAD1"},
  {"role": "anneau-focus", "hex": "#2563EB"}
]}
```
