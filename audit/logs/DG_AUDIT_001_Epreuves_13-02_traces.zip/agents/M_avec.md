# Palettes — application de CFT-05 (couleur et contraste)

Cadre appliqué : `SAVOIR/CRAFT/CFT-05` (palette par rôles, contraste calculé, indice non chromatique, question de convergence) et `ACTION/POLICIES` (contraste WCAG 2.2 AA : 4,5:1 texte courant, 3:1 composants UI / frontières / focus ; jamais de PASS à l'œil). `DIRECTION/VISUAL_TARGET` consulté pour l'ancrage « contexte réel → promesse → relation ».

Méthode de calcul : luminance relative WCAG 2.x (sRGB linéarisé, 0,2126/0,7152/0,0722), ratio (L1+0,05)/(L2+0,05), script Python exécuté dans ce run. Tous les ratios ci-dessous sont des résultats d'outil, pas des estimations.

Statut épistémique : les ratios sont **certains** (calculés). Les effets perçus (« calme », « chantier », « sérieux ») sont des **hypothèses de perception** à vérifier en contexte (CFT-05). Aucune claim de tendance chromatique n'est faite, donc aucun passage `SAVOIR/TOOLS` requis.

---

## Brief 1 — Suivi des dons de sang, hôpital régional (donneurs et infirmiers)

**Tension du produit.** Le sujet appelle le rouge, mais dans un outil clinique le rouge doit rester disponible pour le critique (donneur non éligible, poche rejetée, stock O− en rupture). Si l'identité est rouge, l'alerte se noie.

**Décision de direction.** Structure neutre chaude à accent, avec une séparation stricte : le bordeaux « sang veineux » porte l'identité et les moments donneur (jalons, remerciements), jamais une action ni un statut ; les actions sont à l'encre quasi noire ; le rouge vermillon est réservé au critique.

```json
{"brief": 1, "palette": [
  {"role": "surface.base", "hex": "#FAF7F4"},
  {"role": "surface.raised", "hex": "#FFFFFF"},
  {"role": "surface.sunken", "hex": "#F1ECE7"},
  {"role": "text.primary", "hex": "#1E1A1A"},
  {"role": "text.secondary", "hex": "#5C5250"},
  {"role": "text.inverse", "hex": "#FFFFFF"},
  {"role": "action.primary", "hex": "#2A2426"},
  {"role": "action.primary.hover", "hex": "#453C3F"},
  {"role": "brand.identity", "hex": "#7A1F2B"},
  {"role": "state.critical.text", "hex": "#B3261E"},
  {"role": "state.critical.bg", "hex": "#FCE8E6"},
  {"role": "state.warning.text", "hex": "#8A5A00"},
  {"role": "state.warning.bg", "hex": "#FFF3D6"},
  {"role": "state.success.text", "hex": "#1F6B45"},
  {"role": "state.success.bg", "hex": "#E3F2E9"},
  {"role": "state.info.text", "hex": "#2F5A7A"},
  {"role": "state.info.bg", "hex": "#E6EFF5"},
  {"role": "border.subtle", "hex": "#E2DAD4"},
  {"role": "border.strong", "hex": "#8C817D"},
  {"role": "focus", "hex": "#0B57D0"}
]}
```

**Justification par choix**
- `surface.base #FAF7F4` : un papier légèrement chaud évite la froideur « bloc opératoire » côté donneur tout en restant neutre pour les écrans infirmiers.
- `surface.raised #FFFFFF` / `surface.sunken #F1ECE7` : l'élévation est portée par la valeur, pas par la teinte, pour garder la teinte libre pour les états.
- `text.primary #1E1A1A` : encre chaude presque noire, contraste maximal pour les lectures rapides en poste de prélèvement.
- `text.secondary #5C5250` : métadonnées (dernier don, délai d'ajournement) encore lisibles sur fond enfoncé.
- `action.primary #2A2426` : l'action est à l'encre et non en rouge, pour qu'aucun bouton ne soit confondu avec une alerte.
- `brand.identity #7A1F2B` : le bordeaux ancre l'identité « don de sang » sans concurrencer le vermillon critique, et il est exclu des statuts.
- `state.critical #B3261E / #FCE8E6` : vermillon plus clair et plus orangé que le bordeaux, réservé aux blocages cliniques.
- `state.warning #8A5A00 / #FFF3D6` : ocre pour « à surveiller » (hémoglobine limite, délai presque atteint), distinct du critique.
- `state.success #1F6B45 / #E3F2E9` : vert sourd pour « éligible / poche validée », sans saturation festive.
- `state.info #2F5A7A / #E6EFF5` : bleu ardoise pour les rappels neutres (prochain don possible).
- `border.subtle #E2DAD4` : séparation décorative des cartes (non porteuse d'information, pas soumise au 3:1).
- `border.strong #8C817D` : contour des champs de saisie infirmiers, calculé au-dessus de 3:1.
- `focus #0B57D0` : anneau de focus bleu, seule teinte froide, pour qu'il ne se confonde avec aucun état.

**Contraste calculé (WCAG 2.2 AA)**

| Paire | Ratio | Seuil | Verdict |
|---|---|---|---|
| text.primary / surface.base | 16,16:1 | 4,5 | PASS |
| text.secondary / surface.base | 7,08:1 | 4,5 | PASS |
| text.secondary / surface.sunken | 6,44:1 | 4,5 | PASS |
| text.inverse / action.primary | 15,23:1 | 4,5 | PASS |
| brand.identity / surface.base | 9,56:1 | 4,5 | PASS |
| critical.text / critical.bg | 5,55:1 | 4,5 | PASS |
| warning.text / warning.bg | 5,37:1 | 4,5 | PASS |
| success.text / success.bg | 5,59:1 | 4,5 | PASS |
| info.text / info.bg | 6,29:1 | 4,5 | PASS |
| border.strong / surface.raised | 3,78:1 | 3 | PASS |
| focus / surface.base | 5,98:1 | 3 | PASS |

Point de vigilance calculé : bordeaux `#7A1F2B` vs vermillon `#B3261E` = 1,56:1 seulement. Les deux rouges ne sont donc **pas** distinguables de façon fiable par la couleur ; la séparation repose sur la règle d'usage (le bordeaux n'apparaît jamais sur un statut) et sur les indices ci-dessous.

**Indice non chromatique pour l'information critique**
- Statut d'éligibilité : icône + libellé textuel obligatoire (« Non éligible — ajournement 8 semaines »), jamais une pastille seule.
- Critique : icône triangle « ! » + bordure gauche épaisse 4 px + libellé en gras ; avertissement : icône cercle « i » en contour ; succès : coche.
- Groupe sanguin et stock : groupe écrit en toutes lettres (O−, A+) + niveau en chiffre et en barre à segments comptables, pas en dégradé de rouge.
- Rupture de stock : le mot « RUPTURE » + motif hachuré dans la barre.

**Question de convergence.** Oui en partie : c'est une structure « neutres + un accent », ce que produirait le modèle sans brief. Ce qui la justifie dans le produit : un outil clinique où l'erreur de lecture a un coût, où la saturation doit être réservée aux états ; l'écart retenu est ailleurs — l'accent d'identité (bordeaux) est explicitement retiré des actions et des statuts pour protéger le signal critique. La convergence est donc justifiée et conservée.

**Dark mode.** Non prioritaire (usage de jour en service) ; s'il est demandé, il sera recomposé (surfaces #171415 à élévation claire, bordeaux remonté en luminosité), non inversé.

---

## Brief 2 — Festival de musique électronique itinérant dans des friches industrielles

**Tension du produit.** Le réflexe est « fond noir + néons + dégradé violet-cyan ». Or le festival se distingue par ses lieux : béton, rouille, soufre, cuivre oxydé, signalétique de chantier. La palette doit venir de la matière des friches, et le site sert aussi d'outil de terrain (plan, horaires, sécurité) la nuit.

**Décision de direction.** Identité multicolore structurelle, avec codage par zones : une couleur de matière par scène/halle (rouille-orange, soufre, vert-de-gris), toujours doublée d'une lettre de zone. Thème de jour sur béton clair ; thème « nuit » recomposé pour l'usage sur place.

```json
{"brief": 2, "palette": [
  {"role": "surface.base (béton)", "hex": "#D8D4CC"},
  {"role": "surface.raised (béton lissé)", "hex": "#ECE9E3"},
  {"role": "surface.inverse (bloc charbon)", "hex": "#141312"},
  {"role": "text.primary", "hex": "#141312"},
  {"role": "text.secondary", "hex": "#45413C"},
  {"role": "action.primary (orange sécurité)", "hex": "#FF4F14"},
  {"role": "action.primary.text", "hex": "#141312"},
  {"role": "zone.A halle (rouille)", "hex": "#FF4F14"},
  {"role": "zone.B silo (soufre)", "hex": "#F2C200"},
  {"role": "zone.C tunnel (vert-de-gris)", "hex": "#3E9A8F"},
  {"role": "state.alert.bg (sécurité / annulation)", "hex": "#141312"},
  {"role": "state.alert.text", "hex": "#F2C200"},
  {"role": "state.changed.text (horaire modifié)", "hex": "#8F2600"},
  {"role": "border.strong", "hex": "#6E685F"},
  {"role": "focus", "hex": "#141312"},
  {"role": "night.surface.base", "hex": "#121110"},
  {"role": "night.text.primary", "hex": "#ECE7DE"},
  {"role": "night.text.secondary", "hex": "#A9A196"},
  {"role": "night.action.primary", "hex": "#FF6A33"},
  {"role": "night.state.changed.text", "hex": "#FF8A5C"},
  {"role": "night.border", "hex": "#6A645B"}
]}
```

**Justification par choix**
- `surface.base #D8D4CC` : le béton brut comme fond fait du lieu la marque, à l'opposé du noir néon attendu.
- `surface.raised #ECE9E3` : béton lissé pour les cartes de line-up, élévation par valeur.
- `surface.inverse #141312` : blocs charbon pour les moments forts (affiche d'une édition), rappel des halles sombres sans tout plonger dans le noir.
- `text.primary #141312` : encre charbon, contraste élevé sur béton en plein soleil.
- `text.secondary #45413C` : informations pratiques (accès, navettes) lisibles sur béton.
- `action.primary #FF4F14` + texte `#141312` : orange de sécurité, le code « ici on agit » des chantiers, avec texte noir (le blanc échouerait).
- `zone.A #FF4F14 / zone.B #F2C200 / zone.C #3E9A8F` : rouille, soufre et cuivre oxydé traduisent la chimie des friches en repères de scène.
- `state.alert #141312 / #F2C200` : le couple noir/jaune de la signalétique de danger, compris sans apprentissage.
- `state.changed.text #8F2600` : rouille profonde pour un horaire décalé, visible sans crier comme l'alerte.
- `border.strong #6E685F` : contours de champs et de cartes au-dessus de 3:1 sur béton.
- `focus #141312` : anneau charbon de 3 px avec décalage, le plus fort contraste disponible sur béton.
- `night.*` : recomposition pour téléphone dans l'obscurité — surface charbon, texte craie cassée (pas blanc pur, moins d'éblouissement), orange remonté à `#FF6A33` pour garder 3:1 et plus sur le noir.

**Contraste calculé (WCAG 2.2 AA)**

| Paire | Ratio | Seuil | Verdict |
|---|---|---|---|
| text.primary / béton | 12,56:1 | 4,5 | PASS |
| text.secondary / béton | 6,85:1 | 4,5 | PASS |
| text.primary / béton lissé | 15,32:1 | 4,5 | PASS |
| texte charbon / action orange (= zone A) | 5,64:1 | 4,5 | PASS |
| texte charbon / zone B soufre | 11,04:1 | 4,5 | PASS |
| texte charbon / zone C vert-de-gris | 5,50:1 | 4,5 | PASS |
| alerte jaune / charbon | 11,04:1 | 4,5 | PASS |
| horaire modifié / béton | 5,81:1 | 4,5 | PASS |
| border.strong / béton | 3,73:1 | 3 | PASS |
| focus / béton | 12,56:1 | 3 | PASS |
| nuit : texte / surface | 15,32:1 | 4,5 | PASS |
| nuit : texte secondaire / surface | 7,39:1 | 4,5 | PASS |
| nuit : charbon / action orange | 6,61:1 | 4,5 | PASS |
| nuit : action orange / surface (UI) | 6,61:1 | 3 | PASS |
| nuit : horaire modifié / surface | 8,12:1 | 4,5 | PASS |
| nuit : bordure / surface | 3,22:1 | 3 | PASS |

Échecs calculés, et correction imposée : en aplat sur béton, les couleurs de zone et le bouton orange ne se détachent pas du fond — orange 2,23:1, vert-de-gris 2,28:1, soufre 1,14:1 (tous sous 3:1). Règle de frontière : toute pastille de zone et tout bouton primaire sur béton portent un contour charbon de 2 px (#141312, 12,56:1). Sans ce contour, la palette de jour n'est pas conforme.

**Indice non chromatique pour l'information critique**
- Zones : lettre A / B / C dans chaque pastille, sur le plan et dans les horaires ; la couleur n'est jamais le seul repère du lieu.
- Alerte sécurité / annulation : bandeau à hachures diagonales noir/jaune + pictogramme + mot « ALERTE » ou « ANNULÉ » ; set annulé barré avec le mot écrit.
- Horaire modifié : ancien horaire barré + nouvel horaire en gras + icône horloge.
- Complet : mention « COMPLET » textuelle, bouton désactivé avec libellé, pas un simple grisé.

**Question de convergence.** Non : la palette n'est ni « sombre + néon », ni « dégradé froid ». Elle vient de la matière réelle des friches (béton, rouille, soufre, cuivre oxydé) et de la signalétique de chantier. Le seul point de rapprochement est le thème nuit charbon ; il est justifié par l'usage sur place la nuit (lisibilité, batterie, éblouissement) et reste recomposé, pas néon.

---

## Brief 3 — Outil B2B de réconciliation comptable pour PME

**Tension du produit.** Des tableaux denses consultés longtemps, où l'utilisateur ne doit voir que ce qui reste à traiter. Le piège : rouge/vert pour débit/crédit et un vert vif pour « rapproché », qui rend la masse des lignes réglées plus visible que les écarts.

**Décision de direction.** Structure neutre à accent unique (encre indigo) ; inversion de saillance : le **rapproché s'efface** (vert désaturé, sans fond), l'**écart ressort** (fond ambré). Les montants négatifs ne sont jamais colorés.

```json
{"brief": 3, "palette": [
  {"role": "surface.base", "hex": "#F6F6F3"},
  {"role": "surface.table", "hex": "#FFFFFF"},
  {"role": "surface.row.alt", "hex": "#F9F9F7"},
  {"role": "surface.row.selected", "hex": "#E8ECF7"},
  {"role": "text.primary", "hex": "#16181D"},
  {"role": "text.secondary", "hex": "#555B66"},
  {"role": "text.inverse", "hex": "#FFFFFF"},
  {"role": "action.primary", "hex": "#2C3E91"},
  {"role": "action.link", "hex": "#2C3E91"},
  {"role": "state.ecart.text", "hex": "#9A3412"},
  {"role": "state.ecart.bg", "hex": "#FDEBDD"},
  {"role": "state.bloquant.text", "hex": "#B42318"},
  {"role": "state.bloquant.bg", "hex": "#FDE7E5"},
  {"role": "state.partiel.text", "hex": "#6E5400"},
  {"role": "state.partiel.bg", "hex": "#FBF1CC"},
  {"role": "state.rapproche.text", "hex": "#3F6B52"},
  {"role": "state.suggestion.text", "hex": "#4A3F9E"},
  {"role": "state.suggestion.bg", "hex": "#EEEBFA"},
  {"role": "border.grid", "hex": "#E3E4E0"},
  {"role": "border.input", "hex": "#858A93"},
  {"role": "focus", "hex": "#2C3E91"}
]}
```

**Justification par choix**
- `surface.base #F6F6F3` : gris très légèrement chaud autour du tableau, pour que la table blanche se détache sans ombre.
- `surface.table #FFFFFF` : fond de lecture maximal pour les chiffres.
- `surface.row.alt #F9F9F7` : zébrage à peine perceptible, aide le suivi de ligne sans bruit.
- `surface.row.selected #E8ECF7` : teinte de l'accent très diluée, relie la sélection à l'action.
- `text.primary #16181D` : montants et libellés en contraste maximal, chiffres tabulaires.
- `text.secondary #555B66` : dates, références bancaires, libellés secondaires.
- `action.primary #2C3E91` : encre indigo, unique teinte d'action, distincte de tous les états.
- `action.link #2C3E91` : liens vers pièces justificatives, même teinte que l'action pour ne pas multiplier les codes (souligné).
- `state.ecart #9A3412 / #FDEBDD` : l'ambre-brique est la couleur la plus saillante du tableau, parce que l'écart est le travail.
- `state.bloquant #B42318 / #FDE7E5` : rouge réservé aux écarts au-delà du seuil ou aux doublons suspects.
- `state.partiel #6E5400 / #FBF1CC` : ocre pour un rapprochement partiel (montant couvert en partie).
- `state.rapproche #3F6B52` sans fond : vert sourd, texte seul, pour que les lignes réglées reculent.
- `state.suggestion #4A3F9E / #EEEBFA` : violet-indigo pour les correspondances proposées automatiquement, proche de l'accent car elles appellent une action.
- `border.grid #E3E4E0` : filets de grille décoratifs (la structure est portée par l'alignement, pas par la bordure).
- `border.input #858A93` : champs de filtre et de saisie au-dessus de 3:1.
- `focus #2C3E91` : anneau 2 px + décalage, vital en navigation clavier dans une grille.

**Contraste calculé (WCAG 2.2 AA)**

| Paire | Ratio | Seuil | Verdict |
|---|---|---|---|
| text.primary / surface.table | 17,76:1 | 4,5 | PASS |
| text.secondary / surface.base | 6,31:1 | 4,5 | PASS |
| text.secondary / row.alt | 6,48:1 | 4,5 | PASS |
| text.primary / row.selected | 15,03:1 | 4,5 | PASS |
| text.inverse / action.primary | 9,52:1 | 4,5 | PASS |
| action.link / surface.table | 9,52:1 | 4,5 | PASS |
| ecart.text / ecart.bg | 6,30:1 | 4,5 | PASS |
| bloquant.text / bloquant.bg | 5,55:1 | 4,5 | PASS |
| partiel.text / partiel.bg | 6,33:1 | 4,5 | PASS |
| rapproche.text / surface.table | 6,11:1 | 4,5 | PASS |
| suggestion.text / suggestion.bg | 7,17:1 | 4,5 | PASS |
| border.input / surface.table | 3,47:1 | 3 | PASS |
| focus / row.selected | 8,06:1 | 3 | PASS |

**Indice non chromatique pour l'information critique**
- Chaque statut a une icône et un libellé en colonne dédiée : écart « ≠ » + montant de l'écart signé ; bloquant « ! » + motif (« Doublon probable ») ; partiel demi-cercle ; rapproché coche ; suggestion contour pointillé + « Proposé ».
- Montants négatifs : signe moins et/ou parenthèses, jamais rouge ; débit/crédit en colonnes séparées.
- Tri et filtre par statut textuel (« À traiter : 12 »), pour que l'utilisateur daltonien n'ait pas à scanner les couleurs.

**Question de convergence.** Oui : fond clair, neutres et un seul accent bleu-indigo, c'est la palette qu'un modèle produirait sans brief. Ce qui la justifie : un tableau dense lu longtemps exige que la couleur soit rare et sémantique, et l'accent unique garde l'action lisible. L'écart porteur de sens est ailleurs : la hiérarchie des états est inversée (le succès s'efface, l'écart domine) et aucun montant n'est codé en rouge/vert. Convergence justifiée, conservée.

---

## Limites

- Ratios calculés en sRGB sur les valeurs hex ; non vérifiés en rendu navigateur, sur écran réel ou en plein soleil (brief 2) — **à vérifier** en ACTION.
- Pas de simulation de daltonisme exécutée ; la robustesse repose sur les indices non chromatiques, pas sur la séparation de teinte (les paires bordeaux/vermillon et écart/bloquant sont proches en teinte).
- Les effets de registre (chaleur, sérieux, « chantier ») restent des hypothèses de perception.
