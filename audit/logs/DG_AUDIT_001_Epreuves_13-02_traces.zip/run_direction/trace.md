# Trace — DIR-VELO-001

Sources chargées (via `read_route.py`, texte dans `run/routes/`) : DIRECTION/START, ACTION/STATUS, ACTION/PRECONDITION, ACTION/RUN-DIRECTION ; carte de lecture ACTION pour DIRECTION : ACTION/PIPELINE-DIRECTION, ACTION/VISUAL_PROOF, ACTION/GATE-A, ACTION/GATE-B, ACTION/GATE-C ; table de charge de la skill pour DIRECTION : DIRECTION/VISUAL_TARGET, DIRECTION/FIRST-OBJECT, ACTION/ROUTING, ACTION/FIRST-RENDER, SAVOIR/CRAFT/CFT-00 ; clôture : ACTION/RUN_CARD, ACTION/CLOSE-PACKAGE ; cadrage : DIRECTION/CREATIVE-BOOT, BIBLIOTHEQUE/TENSION (demandé par le boot pour STRUCTURAL-TENSION).
Non chargées (justification) : Atlas, DIRECTION-ATELIER, SAVOIR/STYLE (aucun profil nommé ne change la décision) ; SAVOIR/TYPE, SAVOIR/SOURCE listées par ACTION/ROUTING pour une spec DIRECTION — non chargées par économie, limite déclarée (typographie calibrée sur polices système, aucune recherche de source).

## 1. START — classification

Arbre DIRECTION/START : Q1 (système partagé) non ; Q2 (définir une identité / un premier contact / une surface de marque) **oui** → `ACTION/RUN-DIRECTION`. Mode attendu confirmé : **DIRECTION**.
Protection de niveau : pas de risque critique (santé, sécurité, permission, confidentialité). Le diagnostic ne collecte aucune donnée personnelle dans ce périmètre ; pas de formulaire de compte.

```text
RUN — DIR-VELO-001 — DIRECTION — rendre le diagnostic en ligne perceptible et utilisable comme premier geste de la première scène — V/craft dominant : scène générique « atelier vélo » où le diagnostic reste une promesse textuelle — capture desktop+mobile, revue créative CFT-00, paire B1b — CLASSIFIED
DECISION-INTENT — Trancher si l'objet de diagnostic (vélo pointable + fiche d'atelier) peut porter seul la promesse « on sait ce qui coince avant que vous veniez » au premier regard.
```

Entrée minimale :
- DECISION — quelle relation objet/geste porte la première scène.
- RISK — important (non critique) : V/craft dominant ; risque U secondaire (le visiteur ne connaît pas le nom des pièces).
- SCOPE — première scène (hero + premier geste) ; desktop 1440×900 et mobile 390×844 ; état initial et état « zone choisie ».
- CONSTRAINT — HTML/CSS autonome sans dépendance externe ; aucune donnée réelle (nom, horaires, durées = exemples) ; polices système du runtime de capture.
- NEXT-PROOF — captures v1 desktop/mobile + état après geste ; revue CFT-00 ; paire B1b.
- OWNER — Junior (owner du brief, décision finale). Agent = exécutant, autonomie explicite couvrant ce périmètre (brief qui demande le build) ; reprise/escalade : toute action externe ou publication revient à l'owner.

## 2. Positions et alternative située (PIPELINE §1–3, §6–7)

- **Position retenue — « Fiche d'atelier »** : le vélo dessiné en trait technique est l'objet ; on *pointe* la zone qui coince ; une étiquette d'atelier (le carton qu'on accroche au guidon) se remplit. PROOF-POSITION intégrée, ACTION contextuelle.
- **Alternative située — « Comptoir »** : une conversation question/réponse textuelle (« Qu'est-ce qui se passe ? »), sans dessin. Public visé : personnes qui décrivent mieux un bruit qu'une pièce.
- **Choix** : fiche d'atelier. Avantage vérifiable : pointer une zone supprime la barrière du vocabulaire (on n'a pas à savoir dire « dérailleur ») ; le symptôme reste en mots simples dans un second temps, ce qui récupère l'avantage du comptoir. Pas la plus simple à implémenter (SVG + états) : défendue par le JTBD (arriver à l'atelier avec la bonne info).
- Direction en une phrase : *un vélo à pointer et une fiche d'atelier qui se remplit, pour que le visiteur sache avant de venir ce qui l'attend et quoi apporter — sans vocabulaire technique.*

## 3. CREATIVE-BOOT

```text
DECISION: l'objet de diagnostic peut-il être le hero lui-même (et non une capture latérale) ?
PROMISE: « Dites où ça coince, on vous dit quoi apporter » — venir à l'atelier préparé.
PROOF-OBJECT: vélo en trait technique avec 5 zones pointables + fiche d'atelier qui se remplit (zone, symptôme, orientation, à apporter).
GESTURE: toucher une zone du vélo (ou bouton « Commencer le diagnostic » équivalent clavier).
ANTI-DIRECTIONS: (1) hero SaaS : photo stock de cycliste souriant + titre + 2 boutons + 3 cartes « Rapide / Simple / Solidaire » ;
                 (2) folklore atelier : papier kraft, typos pochoir-bois, clés à molette décoratives, « artisan » vintage.
STRUCTURAL-TENSION: PROOF-POSITION → intégrée ; ACTION → contextuelle (sur l'objet), doublée d'un bouton explicite.
STRUCTURAL-SIGNATURE: l'étiquette d'atelier comme composant authored : le résultat du diagnostic a la forme de l'objet réel qu'on retrouve accroché au vélo à l'atelier.
CFT-TARGETS: Spécificité, Composition (foyer objet+fiche), Résolution (états de la fiche).
ANCHOR-BASIS: hypothèse issue de la connaissance du modèle (étiquettes de réparation, dessins techniques de vélo) — non observée dans ce run (MODEL-KNOWLEDGE-NOT-RECHECKED) ; contrainte produit réelle du brief (diagnostic avant visite).
ANCHOR-LIMIT: ne prouve ni l'adéquation culturelle au public de la coopérative, ni que les coopératives réelles utilisent ces étiquettes, ni la justesse des orientations de diagnostic.
FIRST-OBJECT: scene-v1.html — hero complet avec diagnostic interactif local.
DOMINANT-DEFECT (recherché en premier): le vélo devient une illustration décorative et la fiche un panneau latéral — la promesse redevient textuelle.
```

## 4. VISUAL_TARGET

| Champ | Décision |
|---|---|
| **Thèse** | Une coopérative où l'on répare soi-même avec de l'aide : le site est déjà le comptoir de l'atelier. Public : cyclistes du quotidien, non-experts. Promesse : venir préparé·e. |
| **Conséquence observable** | En un regard : c'est un atelier vélo ; on peut pointer la panne sur le vélo ; le résultat dit quoi apporter et si c'est faisable sur place. |
| **Ancre** | `ANCHOR-GENERATED` (au sens le plus proche disponible : hypothèse non observée, issue de la connaissance du modèle, non d'une image générée). Retenus : carton d'étiquette de réparation (trou œilleté, ficelle, champs manuscrits), trait de dessin technique à épaisseur unique. Rejetés : typographie pochoir, textures kraft/bois, logos de marques de pièces. Non transférable : toute prétention de « pratique réelle » d'un atelier. Enjeu identitaire **élevé** (premier contact de marque) → réserve de calibration « générée seule ». |
| **Silhouette** | Diagonale : titre en haut-gauche, vélo en grande masse horizontale à droite débordant légèrement, étiquette suspendue au guidon qui tombe dans l'axe vertical. Vide calme à gauche sous le titre. |
| **Relations de plans** | Premier plan : vélo + étiquette (objet et preuve) ; second : titre/sous-titre ; fond : papier clair uni. Aucune profondeur décorative ; l'étiquette seule a une ombre portée courte (objet suspendu). |
| **Opération visuelle dominante** | Émergence : une zone pointée s'allume en couleur signal sur le trait noir, et l'étiquette se remplit à la même couleur — lien direct zone → fiche. |
| **Matière / asset** | Route `CODE-NATIVE` : SVG de vélo tracé à la main dans le code, étiquette en HTML/CSS. Rien n'est simulé comme photo. Fallback : sans SVG, la liste des zones reste en boutons texte. Retrait si le dessin ne se lit pas comme un vélo à 390px. |
| **Typographie** | Display condensé gras (pile : Barlow Condensed → Roboto Condensed → Arial Narrow → TeX Gyre Heros Cn → sans-serif) pour le titre ; corps sans-serif système ; données de l'étiquette en monospace (fiche, tampon). Contre-indication : pas de pochoir, pas de script manuscrit. |
| **Objet de preuve** | La fiche d'atelier remplie après le geste (zone, symptôme, orientation, à apporter, durée indicative marquée comme exemple). |
| **Anti-direction** | Voir boot : hero SaaS photo+cartes ; folklore kraft/vintage. Raison : le premier est interchangeable, le second transforme un service pratique en décor nostalgique. |
| **Résolution initiale** | Diagnostic local réellement implémenté (5 zones × 2–3 symptômes), état initial et état rempli, bouton clavier, focus visible, mobile recomposé (vélo au-dessus, fiche en dessous), mentions d'exemple en langage produit. |

## 5. Contrat UI (UI-UX-REALITY, condensé)

- CONTENT-MODEL : 5 zones (Freins, Transmission, Roues & pneus, Vitesses, Direction & jeu) → symptômes → orientation (sur place / pièce à apporter / à laisser à l'atelier).
- PRIMARY-TASK : savoir quoi apporter et si la réparation est faisable pendant une permanence.
- FIRST-GESTURE : pointer une zone ; feedback = zone allumée + fiche remplie + choix du symptôme.
- CRITICAL-STATES : initial (fiche vide invitante), zone choisie, symptôme choisi ; « je ne sais pas » (renvoie à venir sans diagnostic). Pas d'état erreur réseau (tout est local) : N/A-JUSTIFIED.
- CTA : « Commencer le diagnostic » (local, réel) ; « Imprimer ma fiche » (window.print, local réel) ; prise de créneau **non disponible** → déclarée en langage produit.
- VÉRITÉ : nom « Rayon Libre », horaires et durées = exemples, signalés dans l'interface (« nom, horaires et durées d'exemple »). Labels TRUTH/* uniquement ici : fiche = TRUTH/ILLUSTRATIVE + TRUTH/MECHANISM ; orientations = TRUTH/ILLUSTRATIVE.
- EXPECTED-SCOPE : desktop 1440×900 et mobile 390×844, état initial + état après geste (Transmission / « la chaîne saute »).

## 6. Build et observation v1 (ACTION/VISUAL_PROOF)

Scope déclaré : `scene-v1.html`, Chromium headless (Playwright Python), desktop 1440×900 et mobile 390×844, état initial + état après geste réel (clic zone « Chaîne » puis symptôme « La chaîne saute »). Captures : `captures/v1-desktop.png`, `v1-desktop-geste.png`, `v1-mobile.png`, `v1-mobile-geste.png` (pleine page pour les états après geste). Vue de masses : N/A-JUSTIFIED (la capture desktop suffit à lire les masses dans ce périmètre). Contenu long : NOT-VERIFIED. Polices : le runtime n'a pas Barlow/Roboto Condensed ; le titre est rendu par la première police condensée disponible de la pile (limite T).

Lecture légère (atelier d'édition B1b, texte ignoré) : *« un service de réparation vélo artisanal, marque indépendante, qui montre un outil de diagnostic mais sous forme de fiche posée par-dessus une illustration »* — catégorie juste, niveau de preuve : outil visible mais partiellement caché.

## 7. Revue créative unique — SAVOIR/CRAFT/CFT-00 (Creative Quality Review) sur v1

C'est la seule revue créative du run ; Gate C et le creative close la citent, ils ne la refont pas. Auto-revue (auteur du rendu), non indépendante.

- **Présent** — [R1] Le titre condensé « MONTREZ-NOUS OÙ ÇA COINCE. » en trois lignes, avec « OÙ ÇA COINCE. » en rouille, donne une entrée forte et une voix parlée (desktop, haut-gauche). [R2] Le vélo en trait noir épais sur papier clair est lisible comme vélo, sans photo, et les pastilles numérotées se lisent comme des zones à toucher.
- **Spécifique** — [R3] Après le geste, la chaîne et le plateau s'allument en orange et la fiche reçoit un tampon « À VÉRIFIER ENSEMBLE » : la relation zone → fiche → orientation est propre à ce service (on dit quoi apporter, pas « prenez rendez-vous »). [R4] L'étiquette d'atelier (coins coupés, œillet, monospace) est le composant authored ; le produit ne pourrait pas être remplacé par un autre sans changer la scène.
- **Culturellement transformé** — [R5] Le dessin technique d'éclaté et le carton de réparation sont transformés en interface (zones cliquables, champs vides « Touchez le vélo ») plutôt que cités en décor ; mais la transformation reste une hypothèse du modèle, non calibrée sur une référence observée.
- **Encore générique** — [R6] Le bloc gauche (titre + paragraphe + bouton noir + note grise) suit un schéma de hero courant ; il tient par la voix du titre, pas par sa composition.
- **Manque de résolution** — [R7] **Desktop : la fiche, positionnée en absolu en bas à droite, recouvre la roue avant, la fourche et la pastille 3 (« Roue, pneu ») dès l'état initial ; après le geste, elle grandit vers le haut et recouvre aussi le guidon et les pastilles 1 et 5.** L'objet de preuve et l'objet du geste se masquent mutuellement. [R8] Le tampon recouvre la valeur « Chaîne » du champ Zone (desktop et mobile). [R9] Mobile : pastilles 1 et 5 très proches (≈ 20 px d'écart) ; la fiche passe sous la ligne de flottaison (le vélo reste visible dans le premier écran). [R10] Le frein arrière dessiné en « + » sur le hauban se lit comme une croix parasite.
- **Geste de polish le plus rentable** — Transformer la relation spatiale fiche/vélo : sortir la fiche du vélo (juxtaposition) pour que l'objet reste entier et que zone allumée + fiche remplie se lisent ensemble.

**Défaut dominant (un seul) : [R7] occlusion du vélo par la fiche sur desktop** — c'est exactement le défaut redouté dans le boot (la fiche devient un panneau posé par-dessus, le vélo une illustration partielle) ; il touche la décision du run. R8–R10 sont secondaires.

## 8. B1b — paire de discrimination (ACTION/GATE-B)

Déclenché : risque V/craft dominant dans la ligne de run + verdict V reposant sur une composition non confrontée.
- **Décision mise à l'épreuve** : la fiche est *suspendue sur* l'objet (superposition) plutôt que *juxtaposée*.
- **Édition réversible (transformation, rien d'ajouté)** : fiche sortie du positionnement absolu vers une colonne à côté du vélo ; colonne texte 5/12 → 4/12 pour libérer la place. Diff : 5 lignes CSS (voir `diff scene-v1.html scene-v2.html` avant micro-corrections) ; mobile inchangé (captures mobiles identiques au md5).
- **Paire** : avant `captures/v1-desktop.png` / après `captures/b1b-after-desktop.png` (+ états geste `v1-desktop-geste.png` / `b1b-after-desktop-geste.png`).
- **Effet observé** : vélo entier, 5 pastilles visibles et atteignables dans les deux états ; après geste, chaîne orange et fiche remplie lisibles dans le même regard (relation zone → fiche rétablie). Coût observé : le vélo passe d'environ 700 px à environ 460 px de large, le titre passe à quatre lignes avec « ÇA » isolé, un vide apparaît sous le vélo ; nouvel écart introduit : le vélo remonte de 37 px quand la fiche grandit (mesuré).
- **Résultat** : `modified` — la superposition est abandonnée au profit de la juxtaposition.
- **Relation du regard** : auto-comparaison (même auteur), ni indépendante ni aveugle (B3). Aucun regard externe disponible.

## 9. Correction et v2

`scene-v2.html` = après-B1b + trois micro-corrections plancher hors décision B1b, révélées par Gate A : (a) pastille active `#fff` sur `#D9480F` = 4,30:1 < 4,5 → fond `--signal-ink` (6,41:1) ; (b) pastille 5 écrasée en ovale (flex) → `flex:none` ; (c) déplacement de 37 px du vélo après geste → `.stage` alignée en haut (déplacement mesuré : 0 px). Captures `captures/v2-*.png` regardées.
Décision d'arrêt : le défaut dominant R7 est corrigé et ré-observé. Défaut dominant restant : **la présence de l'objet a baissé** (vélo ≈ 460 px dans une colonne de ≈ 880 px, vide dessous, titre à 4 lignes avec orphelin « ÇA ») + tampon sur la valeur Zone (R8). Prochaine action de polish nommée, non exécutée : une v3 relèverait d'une nouvelle décision (échelle de l'objet), hors de la correction unique demandée pour ce run.

## 10. Gate A (v2) — plancher

MEDIUM web ; SCOPE première scène, 2 viewports, états initial/zone/symptôme ; CONFORMANCE-TARGET WCAG 2.2 AA ; METHOD AUTOMATED (calcul de contraste, tabulation Playwright, emulation reduced-motion) + MANUAL (captures) ; COVERAGE-LIMIT : lecteur d'écran, zoom 200 %, contenu long non exécutés ; NEXT-PROOF : passe lecteur d'écran sur l'annonce `aria-live` de la fiche.
- Contraste : ink/papier 13,75 ; muted/papier 6,71 ; muted/fiche 7,32 ; rouille/papier 5,54 ; tampon/fiche 6,04 ; bouton 13,75 ; pastille active 6,41 (après correction) ; orange non-texte/papier 3,72 (≥ 3). PASS.
- Sémantique / nom : zones = `<button aria-pressed>` avec texte ; fiche en `aria-live="polite"` ; SVG `aria-hidden`. PASS (annonce non écoutée : NOT-VERIFIED).
- Focus clavier : ordre Commencer → 1…5 → « Je ne sais pas » ; contour 3 px visible. PASS.
- États : initial, zone choisie, symptôme choisi, « je ne sais pas », impression désactivée tant que la fiche est vide. PASS (dans le scope).
- Contenu honnête : nom, horaires, orientations signalés « données d'exemple » en langage produit ; aucun lien vide (0 `href`). PASS.
- Motion réduite : `animation-name: none` vérifié préférence activée. PASS.
- Cibles : boutons de zone ≥ 42 px (pastille 30 px + padding), lien « Je ne sais pas » 174×24. PASS (seuil 2.5.8).
- Information non chromatique : zone choisie = pastille remplie + libellé dans la fiche, pas la couleur seule. PASS.

## 11. Gate C (v2) — craft sur rendu réel, à partir de la revue §7 et de la paire B1b

Périmètre : desktop 1440×900 et mobile 390×844, états initial et « Chaîne / La chaîne saute », `scene-v2.html`.
- **C1 Stratégie de surface — présent.** Planéité papier + trait découle du produit : le vélo dessiné est l'interface (R2, R5). Aucune photo simulée.
- **C2 Typographie — présent avec réserve.** Trois rôles distincts : display condensé pour la voix (R1), sans-serif pour l'explication, monospace pour la fiche (R4). Réserve : pile de polices non calibrée dans le runtime (fallback), titre à 4 lignes avec « ÇA » orphelin en v2 (constat B1b).
- **C3 Composition — présent avec réserve.** Diagonale titre → vélo → fiche lisible ; l'occlusion R7 est levée par la paire B1b (`modified`). Réserve : objet réduit et vide sous le vélo (coût B1b).
- **C4 Densité optique — retour partiel.** Le bloc gauche reste uniformément espacé et courant (R6) ; en v2 la colonne droite a un vide non attribué sous le vélo.
- **C5 Profondeur — N/A-JUSTIFIED.** Planéité intentionnelle ; seule ombre = fiche décalée de 4/5 px (objet suspendu), cohérente.
- **C6 Résolution située — présent.** La fiche vide dit « Touchez le vélo », « Imprimer ma fiche » reste désactivé tant qu'il n'y a rien à imprimer, « Je ne sais pas où c'est » donne une sortie honnête, le tampon catégorise l'orientation (R3). Réserve : tampon qui masque la valeur Zone (R8).
Aucun critère bloquant absent ; signaux faibles convergents sur la présence de l'objet (C3/C4) → réserve V et prochaine action, pas de retour immédiat.

## 12. Statuts et clôture

- V/U/A/T : V `PASS-WITH-RESERVATION` ; U `NOT-VERIFIED` (geste fonctionnel observé, compréhension par des non-experts non testée) ; A `PASS-WITH-RESERVATION` (lecteur d'écran non exécuté) ; T `PASS` (aucun débordement horizontal à 390 et 1440, aucune dépendance réseau ; fallback de police en limite).
- Statut de direction : `PARTIALLY-HELD` — la relation objet → fiche est tenue, mais la silhouette visée (« vélo en grande masse ») est affaiblie par la juxtaposition ; l'owner n'a pas accepté cette différence, donc pas `HELD-WITH-ACCEPTED-DIFFERENCE`.
- Calibration : `generated_only_reserved` — « Direction calibrée uniquement sur hypothèse générée, sans référence observée ni contrainte réelle. »
- Verdict global : voir `run_card.json`.
- DECISION-CHANGE — CHANGED : la fiche passe de superposée à juxtaposée ; l'objet de diagnostic porte la promesse au premier regard, au prix d'une présence réduite à reprendre.
- NEXT-ACTION (hors projection) : agrandir le vélo à la pleine hauteur de sa colonne (fiche ≤ 300 px), déplacer le tampon hors du champ Zone, recaler le titre en 3 lignes.
- EXIT-CONDITION (hors projection) : vélo ≥ 60 % de la largeur du stage, sans occlusion, dans les deux états ; tampon sans recouvrement ; regard externe obtenu sur la direction.

## 13. Évaluation du rendu final (scene-v2) : QUICKSTART §6 puis DIRECTION/FIRST-OBJECT

Lentilles de relecture après clôture ; elles ne modifient ni la RUN_CARD ni les verdicts (pas de seconde revue créative : elles servent à comparer les deux grilles).

| Dimension | QUICKSTART §6 (« ce que le rendu doit rendre visible ») | FIRST-OBJECT (« suffisant quand / retour si ») |
|---|---|---|
| Présence | Tenue : position perceptible (titre + trait). | Tenue, signal faible : la masse dominante est passée au titre, pas à l'objet. |
| Foyer | Tenu : point d'entrée = titre. | **Lacune** : titre de 4 lignes et objet se disputent la dominance ; bouton « Commencer » et pastilles = deux entrées vers le même geste. |
| Signature | Tenue : fiche d'atelier. | Tenue. |
| Intégration | Tenue : le geste rend la promesse tangible ; aucun élément sans conséquence. | **Lacunes** : « mal cadré » → vélo réduit avec vide dessous ; chaîne « objet avant bénéfices » non tenue sur mobile (vélo après titre, texte, bouton et note). |
| Résolution | Tenue : assez construit pour révéler les défauts. | **Lacune** : « reporte la décision à une future passe de polish » → l'échelle de l'objet est effectivement reportée. |
| Désirabilité située | Tenue. | Tenue. |
| Vérité de scène | Tenue : exemples marqués. | **Lacune faible** : le tampon d'orientation a l'autorité visuelle d'un verdict d'atelier ; « Indicatif » est près de l'objet mais « données d'exemple » est loin (pied de page). CTA : tous réels ou limite déclarée — tenu. |
| Résilience visible | NOT-VERIFIED : contenu long. | NOT-VERIFIED : contenu long ; fiche sous la ligne de flottaison mobile. |

Bilan : §6 ne remonte qu'une lacune (contenu long non vérifié) ; FIRST-OBJECT en remonte cinq supplémentaires, toutes déjà présentes ou compatibles avec le défaut dominant restant du creative close. L'écart vient des colonnes « Retour si » et des règles annexes (chaîne promesse → objet → geste, objet avant bénéfices, règle CTA, marquage près de l'objet) que §6 ne reprend pas, alors qu'il se déclare projection « dans le même ordre et sous les mêmes noms ».
