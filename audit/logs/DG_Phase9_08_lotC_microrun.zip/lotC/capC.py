import json,sys
from pathlib import Path
from playwright.sync_api import sync_playwright
O=Path(__file__).resolve().parent
AXE=Path('/tmp/axe/node_modules/axe-core/axe.min.js').read_text()
files=sys.argv[1:]
PAL=r"""()=>{const bg=getComputedStyle(document.body).backgroundColor; const fams=new Set(), cols=new Set();
for(const e of document.querySelectorAll('body *')){const s=getComputedStyle(e); if(e.getBoundingClientRect().width){fams.add(s.fontFamily.split(',')[0]); if(s.backgroundColor!=='rgba(0, 0, 0, 0)')cols.add(s.backgroundColor); cols.add(s.color)}}
const h=document.querySelector('h1'); return {bodyBg:bg,fonts:[...fams],colors:[...cols].slice(0,24),h1Font:h?getComputedStyle(h).fontFamily:null,h1Size:h?getComputedStyle(h).fontSize:null,overflowX:document.documentElement.scrollWidth>document.documentElement.clientWidth}}"""
log={}
with sync_playwright() as p:
    br=p.chromium.launch()
    for f in files:
        stem=Path(f).stem
        for vw,vh in [(1440,900),(390,844)]:
            c=br.new_context(viewport={'width':vw,'height':vh}); pg=c.new_page(); pg.goto(f'file://{O}/{f}'); pg.wait_for_timeout(1500)
            pg.screenshot(path=str(O/f'{stem}_{vw}_first.png')); pg.screenshot(path=str(O/f'{stem}_{vw}_full.png'),full_page=True)
            log[f'{stem}_{vw}']=pg.evaluate(PAL)
            pg.add_script_tag(content=AXE); log[f'{stem}_{vw}_axe']=pg.evaluate("async()=>(await axe.run(document,{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes.length,v.nodes.slice(0,3).map(n=>n.target.join(' '))])"); c.close()
        c=br.new_context(viewport={'width':1440,'height':900},forced_colors='active'); pg=c.new_page(); pg.goto(f'file://{O}/{f}'); pg.wait_for_timeout(1200); pg.screenshot(path=str(O/f'{stem}_forced.png')); c.close()
        c=br.new_context(viewport={'width':1440,'height':900},java_script_enabled=False); pg=c.new_page(); pg.goto(f'file://{O}/{f}'); pg.wait_for_timeout(500); pg.screenshot(path=str(O/f'{stem}_nojs.png')); c.close()
    br.close()
json.dump(log,open(O/'capC_log.json','w'),ensure_ascii=False,indent=1); print(json.dumps(log,ensure_ascii=False)[:3000])
