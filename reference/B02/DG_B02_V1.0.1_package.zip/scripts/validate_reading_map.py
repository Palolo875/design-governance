#!/usr/bin/env python3
"""Validate the derived reading and multi-perspective map without creating authority."""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OFFICIAL = ROOT / "V1" / "official" if (ROOT / "V1" / "official").is_dir() else ROOT / "official"
MAP = OFFICIAL / "READING_MAP.md"
REQUIRED = (
    "Statut :** guide dérivé non normatif",
    "## Chemin canonique de démarrage",
    "## Routage minimal par décision",
    "## Activation multi-perspective",
    "## Handoff minimal commun",
    "## Résolution des routes",
    "## Locators principaux",
    "DIRECTION/START",
    "ACTION/RUN-LITE",
    "ACTION/CLOSE-EXIT-CHECK",
    "SAVOIR/ROUTING",
    "BIBLIOTHEQUE/SELECT",
    "## Condition d’arrêt",
    "N/A-JUSTIFIED",
    "NOT-VERIFIED",
)
OWNER_MAP = {
    "DIRECTION/*": OFFICIAL / "DIRECTION.md",
    "ACTION/*": OFFICIAL / "ACTION.md",
    "SAVOIR/*": OFFICIAL / "SAVOIR.md",
    "BIBLIOTHEQUE/*": OFFICIAL / "BIBLIOTHEQUE.md",
    "CHANGELOG/*": OFFICIAL / "CHANGELOG.md",
}


def fail(message: str) -> None:
    raise SystemExit(f"READING MAP VALIDATION FAILED — {message}")


def check_locator_destinations(text: str) -> set[str]:
    """Ensure every listed locator resolves to the exact heading it names."""
    if "## Locators principaux" not in text:
        fail("section des locators principaux absente")
    text = text.split("## Locators principaux", 1)[1]
    if "## Condition d’arrêt" in text:
        text = text.split("## Condition d’arrêt", 1)[0]
    rows = []
    for line in text.splitlines():
        if not line.startswith("| `") or " | `" not in line or not line.endswith(" |"):
            continue
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if len(cells) != 2 or not cells[0].startswith("`") or not cells[0].endswith("`"):
            continue
        locator = cells[0][1:-1]
        destination = cells[1]
        match = re.fullmatch(r"`([^`]+)`\s+—\s+`(.+)`", destination)
        if not match:
            fail(f"destination de locator mal formée : {locator}")
        owner_name, heading = match.groups()
        owner_name = owner_name.strip()
        heading = heading.strip().replace("\\`", "`")
        owner = OFFICIAL / owner_name
        if not owner.is_file():
            fail(f"fichier propriétaire absent pour {locator} : {owner_name}")
        headings = {line.strip() for line in owner.read_text(encoding="utf-8").splitlines() if line.lstrip().startswith("#")}
        if heading not in headings:
            fail(f"titre de locator introuvable : {locator} -> {owner_name} — {heading}")
        if locator in rows:
            fail(f"locator dupliqué dans la table : {locator}")
        rows.append(locator)
    if len(rows) < 10:
        fail("table des locators principaux incomplète ou illisible")
    return set(rows)


LOCATOR_PATTERN = re.compile(r"\b(?:DIRECTION|ACTION|SAVOIR|BIBLIOTHEQUE)/[A-Z][A-Z0-9_-]*[A-Z0-9]")
MODE_ROUTES = re.compile(r"ACTION/RUN-(?:LITE|ITER|STANDARD|DIRECTION|SYSTEM)")


def check_cited_locators(listed: set[str]) -> None:
    """Tout locator cité dans le package doit être servi par la CLI."""
    skill_dirs = [ROOT / "skills", ROOT / "skill"]
    sources = sorted(OFFICIAL.glob("*.md")) + [ROOT / "README.md"]
    for directory in skill_dirs:
        if directory.is_dir():
            sources.extend(sorted(directory.rglob("*.md")))
    for source in sources:
        if not source.is_file():
            continue
        for locator in sorted(set(LOCATOR_PATTERN.findall(source.read_text(encoding="utf-8")))):
            if locator not in listed:
                fail(f"locator cité mais absent de la table CLI : {locator} ({source.relative_to(ROOT)})")


def check_routing_minima(text: str) -> None:
    """Une route de mode ne peut pas être présentée comme ajout conditionnel."""
    section = text.split("## Routage minimal par décision", 1)[1].split("\n## ", 1)[0]
    for line in section.splitlines():
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if len(cells) != 4 or cells[0].startswith("---") or cells[0] == "Décision dominante":
            continue
        misplaced = MODE_ROUTES.findall(cells[2])
        if misplaced:
            fail(f"route de mode en ajout conditionnel : {', '.join(misplaced)} ({cells[0]})")


def normalize_field(field: str) -> str:
    return re.sub(r"\s+", "", field).upper()


def check_handoff_fields(text: str) -> None:
    """Le handoff de la carte doit reprendre tous les champs d’ACTION/HANDOFF."""
    action = (OFFICIAL / "ACTION.md").read_text(encoding="utf-8")
    owner_block = action.split("### ACTION/HANDOFF", 1)[1].split("```text", 1)[1].split("```", 1)[0]
    owner_fields = {normalize_field(field) for field in re.split(r"—|\n", owner_block) if field.strip()}
    map_block = text.split("## Handoff minimal commun", 1)[1].split("```text", 1)[1].split("```", 1)[0]
    map_fields = {normalize_field(line.split(":", 1)[0]) for line in map_block.splitlines() if ":" in line}
    missing = sorted(owner_fields - map_fields)
    if missing:
        fail(f"handoff de la carte incomplet au regard d’ACTION/HANDOFF : {', '.join(missing)}")


def main() -> int:
    if not MAP.is_file():
        fail("READING_MAP.md absent")
    text = MAP.read_text(encoding="utf-8")
    for item in REQUIRED:
        if item not in text:
            fail(f"élément obligatoire absent : {item}")
    for route, owner in OWNER_MAP.items():
        if route not in text:
            fail(f"propriétaire de route absent : {route}")
        if not owner.is_file():
            fail(f"fichier propriétaire absent : {owner}")
    for target in re.findall(r"\]\(([^)]+)\)", text):
        target = target.split("#", 1)[0]
        if target.startswith(("http://", "https://", "mailto:")):
            continue
        if not target:
            continue
        if not (MAP.parent / target).exists():
            fail(f"lien relatif non résolu : {target}")
    listed = check_locator_destinations(text)
    check_cited_locators(listed)
    check_routing_minima(text)
    check_handoff_fields(text)
    # The map must remain derived and cannot introduce a competing classifier.
    if "source" not in text or "normative" not in text or "ne reclassifie pas" not in text:
        fail("frontière de non-autorité ou de non-reclassification absente")
    print("READING MAP VALIDATION PASSED — carte dérivée, propriétaires, handoff et liens contrôlés")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

