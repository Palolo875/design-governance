# READING_MAP — carte dérivée de lecture et d’activation

**Statut :** guide dérivé non normatif. Les cinq sources normatives, le schéma `RUN_CARD` et les validateurs propriétaires font foi en cas de divergence.

## Utilisation

Cette carte réduit la recomposition mentale du lecteur. Elle ne crée ni mode, ni gate, ni axe, ni statut, ni verdict, ni owner de décision supplémentaire. Elle indique seulement où commencer, quoi charger, ce qui doit sortir et quand transmettre.

Pour composer plusieurs capacités selon un résultat recherché — direction, beauté située, créativité, usage, preuve, vitesse ou système — consulter [`ORCHESTRATION_MAP.md`](ORCHESTRATION_MAP.md). Cette carte d’orchestration est dérivée et complémentaire : `READING_MAP` résout le premier chemin ; `ORCHESTRATION_MAP` aide à ajuster la combinaison et l’intensité sans remplacer les propriétaires normatifs.

## Chemin canonique de démarrage

1. Localiser la version V1 réellement fournie.
2. Lire `QUICKSTART.md` ou cette carte si le besoin est déjà identifiable.
3. Ouvrir `DIRECTION/START` pour classer le mode et le risque dominant.
4. Charger uniquement le propriétaire capable de modifier la prochaine décision.
5. Ouvrir `ACTION` dès qu’un artefact, une observation, une preuve, un état ou une clôture est concerné.
6. Persister la sortie selon le contrat `RUN_CARD` lorsque le run doit être repris, comparé ou fermé.

`DIRECTION/START` reste la seule classification. Cette carte ne reclassifie pas.

## Constitution minimale

Les cinq absolus de `DIRECTION` protègent la baseline : direction perceptible, ancre inspectable, preuves applicables, mode et prochaine preuve déclarés avant l’exécution, coordination du réel et du beau. La conformité ne remplace ni la direction ni la preuve. Pour le contrat complet, ouvrir [`DIRECTION.md`](DIRECTION.md#les-cinq-règles-absolues).

## Routage minimal par décision

| Décision dominante | Première lecture | Ajouter seulement si nécessaire | Sortie minimale |
|---|---|---|---|
| Brief vague ou risque inconnu | `DIRECTION/START` | `DIRECTION/EXTERNAL-START` | Clarification, mode, risque, owner et prochaine preuve |
| Correction locale | `DIRECTION/START` → `ACTION/RUN-LITE` ou `RUN-ITER` | `SAVOIR` ou `BIBLIOTHEQUE` si la décision change | Delta, scope, preuve, limite, prochaine action |
| Nouvelle surface opérationnelle | `DIRECTION/START` → `ACTION/RUN-STANDARD` | `BIBLIOTHEQUE/SELECT`, `SAVOIR/CONTEXT` | Artefact, hiérarchie, états, preuve, risque restant |
| Direction identitaire | `DIRECTION/START` → `DIRECTION/VISUAL_TARGET` → `ACTION/RUN-DIRECTION` | `DIRECTION/FIRST-OBJECT`, `SAVOIR/CRAFT` | Direction, objet, capture, écarts, preuve, limite |
| Structure ou composant partagé | `DIRECTION/START` → `ACTION/RUN-SYSTEM` (migration, rollback, non-régression et entrée `CHANGELOG` inclus) | `BIBLIOTHEQUE/COMPONENTS` si un composant est touché, `SAVOIR/SYSTEM` | Consumers, owner, compatibilité, migration, rollback |
| Preuve, vérification ou clôture | `ACTION` | Gate et route correspondant au risque | Observation, interprétation, décision, preuve, limite, sortie |
| Règle ou route durable | `CHANGELOG` et source propriétaire | `ACTION` pour preuve et `BIBLIOTHEQUE/EVOLUTION` si structure | Décision, source, owner, compatibilité, preuve, revue |

## Activation multi-perspective

Une perspective ne se charge que si son déclencheur peut modifier la décision. `N/A-JUSTIFIED` est une sortie valide lorsque la perspective est examinée et non applicable. La colonne « Non-chargement » ne dispense jamais d’un minimum que `ACTION/PRECONDITION` impose au mode classé.

| Perspective | Déclencheur | Lecture minimale | Sortie | Non-chargement |
|---|---|---|---|---|
| Direction | Identité, présence, premier objet ou composition ouverte | `DIRECTION` + cible | Thèse, objet, ancre, relation, défaut dominant | Décision visuelle intacte et delta strictement local |
| Production | Artefact ou modification à construire | `ACTION` + route du mode | Artefact, scope, état et prochaine preuve | Aucun artefact ou simple clarification |
| Usage | JTBD, action, confiance, récupération ou tâche critique | `ACTION/UI-UX-REALITY` | Geste, résultat, état, limite | Aucun impact sur usage déclaré |
| Contenu | Données, longueur, langue, claim ou état | `SAVOIR/TYPE` ou `STATE` | Contenu crédible, hiérarchie, limite | Contenu inchangé et non déterminant |
| Responsive | Mobile, zoom, reflow ou viewport critique | `ACTION/UI-UX-REALITY` + `SAVOIR/CONTEXT` | Recomposition, priorité, preuve de scope | Aucun changement de viewport ou risque déclaré |
| Accessibilité | Focus, clavier, sémantique, contraste, motion ou population critique | `SAVOIR/CONTEXT` + `ACTION/GATE-A` | Méthode, scope, résultat, limite | Aucune surface interactive, aucun contenu perçu ni état touché ; sinon les contrôles applicables de `ACTION/GATE-A` restent dus. `N/A-JUSTIFIED` exige cette raison vérifiable ; une simple déclaration de hors-scope ne suffit pas. |
| Runtime | Compatibilité, performance, fallback ou plateforme | `SAVOIR/TECH` + `ACTION` | Runtime, méthode, erreur, fallback, preuve | Aucun claim technique |
| Preuve | Claim, capture, mesure, verdict ou clôture | `ACTION` | Claim, méthode, scope, date, limite, locator | Aucune affirmation de résultat |
| Maintenance | Consumer partagé, trace, migration ou reprise | `ACTION` + `CHANGELOG` si durable | Owner, diff, compatibilité, revue, réouverture | Delta local sans conséquence future |
| Coordination | Handoff, escalade, action externe ou owner suivant | `ACTION/AUTHORITY` et sortie | Destinataire, autonomie, confirmation, prochaine action | Aucun transfert |
| Mémoire | Décision durable, version, réserve ou migration | `RUN_CARD` et `CHANGELOG` si promotion | Décision, date, statut, preuve, réserve, revue | Décision strictement éphémère |

## Handoff minimal commun

Ce bloc réutilise les champs existants ; il ne remplace pas `ACTION` ni le schéma `RUN_CARD`.

```text
MODE:
DECISION:
RISK:
SCOPE:
ARTIFACT:
OBSERVATION / METHOD:
PROOF / TRACE-LOCATOR:
LIMIT / NOT-VERIFIED:
DECISION-CHANGE:
NEXT-ACTION:
OWNER:
NEXT-PROOF:
EXIT-CONDITION:
```

Les champs non applicables doivent être marqués `N/A-JUSTIFIED` ; ils ne doivent pas être inventés. Si un run est persistant, la projection `RUN_CARD` et son validateur restent obligatoires selon le mode et le risque.

## Résolution des routes

Les noms de route sont des locators documentaires. Pour les résoudre, utiliser le fichier propriétaire, puis son titre exact. Un renvoi qui ne résout pas doit être déclaré obsolète, conceptuel ou `NOT-VERIFIED`; il ne doit jamais être traité comme une instruction active par supposition.

| Préfixe | Propriétaire |
|---|---|
| `DIRECTION/*` | `DIRECTION.md` |
| `ACTION/*` | `ACTION.md` |
| `SAVOIR/*` | `SAVOIR.md` |
| `BIBLIOTHEQUE/*` | `BIBLIOTHEQUE.md` |
| `CHANGELOG/*` | `CHANGELOG.md` |
| `RUN_CARD` | `schemas/run_card.schema.json`, exemple et validateur |

`RUN_CARD` est un **adaptateur machine**, pas un locator Markdown résolvable par `scripts/read_route.py`. Pour l’inspecter ou le valider, utiliser le schéma, l’exemple et `scripts/validate_run_card.py`; ne pas l’invoquer comme une route documentaire.

## Locators principaux

Les locators ci-dessous sont des titres exacts dans la baseline V1. Tout locator cité par une source normative, une façade ou la skill du package figure dans cette table et reste servi par `scripts/read_route.py` ; `scripts/validate_reading_map.py` le vérifie. Un nom absent de cette table n’est pas une route : il doit être résolu par son propriétaire ou déclaré `NOT-VERIFIED`, jamais deviné.

| Locator | Destination exacte |
|---|---|
| `DIRECTION/START` | `DIRECTION.md` — `## DIRECTION/START — classer avant d’agir` |
| `DIRECTION/FIRST-OBJECT` | `DIRECTION.md` — `## DIRECTION/FIRST-OBJECT — compiler le brief et produire le premier objet` |
| `DIRECTION/VISUAL_TARGET` | `DIRECTION.md` — `## DIRECTION/VISUAL_TARGET — rendre la direction pilotable` |
| `DIRECTION/DOUBLE-LOOP` | `DIRECTION.md` — `## DIRECTION/DOUBLE-LOOP — créer puis apprendre` |
| `DIRECTION/FAST-PATH` | `DIRECTION.md` — `### DIRECTION/FAST-PATH — encadré d’exécution courte` |
| `ACTION/RUN-LITE` | `ACTION.md` — `### \`ACTION/RUN-LITE\`` |
| `ACTION/RUN-ITER` | `ACTION.md` — `### \`ACTION/RUN-ITER\`` |
| `ACTION/RUN-STANDARD` | `ACTION.md` — `### \`ACTION/RUN-STANDARD\`` |
| `ACTION/RUN-DIRECTION` | `ACTION.md` — `### \`ACTION/RUN-DIRECTION\`` |
| `ACTION/RUN-SYSTEM` | `ACTION.md` — `### \`ACTION/RUN-SYSTEM\`` |
| `ACTION/FIRST-RENDER` | `ACTION.md` — `## ACTION/FIRST-RENDER — qualité initiale attendue` |
| `ACTION/FAST-PATH` | `ACTION.md` — `## ACTION/FAST-PATH — preuve minimale sans rituel` |
| `ACTION/UI-UX-REALITY` | `ACTION.md` — `### ACTION/UI-UX-REALITY — construire l’interface et la tâche ensemble` |
| `ACTION/CLOSE-PACKAGE` | `ACTION.md` — `## ACTION/CLOSE-PACKAGE — paquet de clôture` |
| `ACTION/GATE-A` | `ACTION.md` — `## ACTION/GATE-A — plancher objectivable` |
| `ACTION/ROUTING` | `ACTION.md` — `## ACTION/ROUTING — prérequis de jugement et de structure` |
| `ACTION/CLOSE-EXIT-CHECK` | `ACTION.md` — `## ACTION/CLOSE-EXIT-CHECK — test de sortie canonique` |
| `SAVOIR/READ` | `SAVOIR.md` — `## SAVOIR/READ — comment utiliser cette bibliothèque` |
| `SAVOIR/ROUTING` | `SAVOIR.md` — `## SAVOIR/ROUTING — routes stables` |
| `SAVOIR/CRAFT` | `SAVOIR.md` — `# SAVOIR/CRAFT — anti-slop, composition et expression` |
| `BIBLIOTHEQUE/READ` | `BIBLIOTHEQUE.md` — `## BIBLIOTHEQUE/READ — responsabilités et convention de route` |
| `BIBLIOTHEQUE/SELECT` | `BIBLIOTHEQUE.md` — `## BIBLIOTHEQUE/SELECT — choisir avant de composer` |
| `BIBLIOTHEQUE/COMPONENTS` | `BIBLIOTHEQUE.md` — `## BIBLIOTHEQUE/COMPONENTS — couches et dépendances` |
| `BIBLIOTHEQUE/EVOLUTION` | `BIBLIOTHEQUE.md` — `## BIBLIOTHEQUE/EVOLUTION — promotion et dépréciation` |
| `DIRECTION/CREATIVE-BOOT` | `DIRECTION.md` — `### DIRECTION/CREATIVE-BOOT — activer la boucle avant le premier pixel` |
| `DIRECTION/DAILY` | `DIRECTION.md` — `## DIRECTION/DAILY — charger proportionnellement` |
| `DIRECTION/DIRECTION-ATELIER` | `DIRECTION.md` — `## DIRECTION/DIRECTION-ATELIER — module officiel de direction située` |
| `DIRECTION/DOMAIN-FRAME` | `DIRECTION.md` — `### DIRECTION/DOMAIN-FRAME — adapter le design au domaine` |
| `DIRECTION/EXTERNAL-START` | `DIRECTION.md` — `## DIRECTION/EXTERNAL-START — activation portable sur brief vague` |
| `DIRECTION/SERVICE-BOUNDARY` | `DIRECTION.md` — `## DIRECTION/SERVICE-BOUNDARY — ne pas confondre relation et contrat` |
| `ACTION/ANTI-SLOP` | `ACTION.md` — `## ACTION/ANTI-SLOP — conséquence de gate` |
| `ACTION/AUTHORITY` | `ACTION.md` — `### ACTION/AUTHORITY — portée d’action et reprise` |
| `ACTION/GATE-B` | `ACTION.md` — `## ACTION/GATE-B — jugement contextualisé et risques` |
| `ACTION/GATE-C` | `ACTION.md` — `## ACTION/GATE-C — craft sur rendu réel` |
| `ACTION/HANDOFF` | `ACTION.md` — `### ACTION/HANDOFF — sortie minimale commune` |
| `ACTION/MAINTENANCE` | `ACTION.md` — `## ACTION/MAINTENANCE — recette documentaire` |
| `ACTION/OVERRIDE` | `ACTION.md` — `## ACTION/OVERRIDE — FAIL-ASSUMED et péremption` |
| `ACTION/PIPELINE-DIRECTION` | `ACTION.md` — `## ACTION/PIPELINE-DIRECTION — direction vérifiable` |
| `ACTION/POLICIES` | `ACTION.md` — `## ACTION/POLICIES — contraste et inspection` |
| `ACTION/PRECONDITION` | `ACTION.md` — `## ACTION/PRECONDITION — mode, capacité et preuve` |
| `ACTION/RUN` | `ACTION.md` — `## ACTION/RUN — routes d’exécution` |
| `ACTION/RUN_CARD` | `ACTION.md` — `## ACTION/RUN_CARD — carte de run minimale` |
| `ACTION/STATUS` | `ACTION.md` — `## ACTION/STATUS — états, issues et verdicts` |
| `ACTION/STRUCTURED-PROOF` | `ACTION.md` — `## ACTION/STRUCTURED-PROOF — contrats avant build` |
| `ACTION/VISUAL_PROOF` | `ACTION.md` — `## ACTION/VISUAL_PROOF — rendre la direction vérifiable` |
| `SAVOIR/CONTEXT` | `SAVOIR.md` — `# SAVOIR/CONTEXT — accessibilité, contexte et robustesse` |
| `SAVOIR/DESIGN-ATLAS` | `SAVOIR.md` — `# SAVOIR/DESIGN-ATLAS — familles et responsabilités` |
| `SAVOIR/FAST-PATH` | `SAVOIR.md` — `### SAVOIR/FAST-PATH — juger sans produire un dossier` |
| `SAVOIR/FRAME` | `SAVOIR.md` — `# SAVOIR/FRAME — fondations et cadrage` |
| `SAVOIR/INTEGRITY` | `SAVOIR.md` — `# SAVOIR/INTEGRITY — limites, délégation et critique` |
| `SAVOIR/SOURCE` | `SAVOIR.md` — `# SAVOIR/SOURCE — ancre et sourcing visuel` |
| `SAVOIR/STATE` | `SAVOIR.md` — `# SAVOIR/STATE — craft, composants et états` |
| `SAVOIR/STYLE` | `SAVOIR.md` — `# SAVOIR/STYLE — profils contrôlés et dials` |
| `SAVOIR/SYSTEM` | `SAVOIR.md` — `# SAVOIR/SYSTEM — tokens et composants` |
| `SAVOIR/TECH` | `SAVOIR.md` — `# SAVOIR/TECH — techniques, tests et stack` |
| `SAVOIR/TOOLS` | `SAVOIR.md` — `# SAVOIR/TOOLS — claims, tendances et calibration` |
| `SAVOIR/TYPE` | `SAVOIR.md` — `# SAVOIR/TYPE — typographie et données` |
| `BIBLIOTHEQUE/COMPAT` | `BIBLIOTHEQUE.md` — `## BIBLIOTHEQUE/COMPAT — combiner avec une raison` |
| `BIBLIOTHEQUE/CONTRACTS` | `BIBLIOTHEQUE.md` — `## BIBLIOTHEQUE/CONTRACTS — contrat commun de route` |
| `BIBLIOTHEQUE/DERIVE` | `BIBLIOTHEQUE.md` — `### BIBLIOTHEQUE/DERIVE — inventer sans fabriquer un menu` |
| `BIBLIOTHEQUE/FAST-PATH` | `BIBLIOTHEQUE.md` — `### BIBLIOTHEQUE/FAST-PATH — vérifier avant de sélectionner` |
| `BIBLIOTHEQUE/GATE` | `BIBLIOTHEQUE.md` — `## BIBLIOTHEQUE/GATE — contrôle de module structurel complémentaire` |
| `BIBLIOTHEQUE/GRID` | `BIBLIOTHEQUE.md` — `## BIBLIOTHEQUE/GRID — comment le regard circule` |
| `BIBLIOTHEQUE/MICRO` | `BIBLIOTHEQUE.md` — `## BIBLIOTHEQUE/MICRO — unités denses` |
| `BIBLIOTHEQUE/MODIFIER` | `BIBLIOTHEQUE.md` — `## BIBLIOTHEQUE/MODIFIER — comportements transversaux` |
| `BIBLIOTHEQUE/OBJECT` | `BIBLIOTHEQUE.md` — `## BIBLIOTHEQUE/OBJECT — quelle preuve devient tangible` |
| `BIBLIOTHEQUE/SCENE` | `BIBLIOTHEQUE.md` — `## BIBLIOTHEQUE/SCENE — comment la promesse devient une surface` |
| `BIBLIOTHEQUE/SIGNATURE` | `BIBLIOTHEQUE.md` — `### BIBLIOTHEQUE/SIGNATURE — rendre l’écart vérifiable` |
| `BIBLIOTHEQUE/SUPPORT` | `BIBLIOTHEQUE.md` — `## BIBLIOTHEQUE/SUPPORT — où la surface vit` |
| `BIBLIOTHEQUE/TENSION` | `BIBLIOTHEQUE.md` — `### BIBLIOTHEQUE/TENSION — diverger avant de sélectionner` |

## Condition d’arrêt

Arrêter la lecture lorsque la décision, le risque, le propriétaire, la sortie, la prochaine preuve et la limite sont suffisamment explicites pour le prochain propriétaire. Continuer uniquement si une section supplémentaire peut modifier l’un de ces éléments. Une décision visuelle peut rester `EXPLORATORY` ; une validation documentaire ne devient pas une preuve d’usage, d’accessibilité, de performance ou de qualité réelle.

