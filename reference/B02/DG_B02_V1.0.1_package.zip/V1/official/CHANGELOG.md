# Changelog — Design Governance V1.0.1

**Version publique :** `V1.0.1`  
**Statut expérimental :** Design Governance V1.0.1 est une expérimentation maintenue.  
**Date de publication :** candidat du 2026-09-25, non publié (baseline précédente V1.0.0 du 2026-09-19)  
**Usage recommandé :** pilote contrôlé, supervision humaine et preuve adaptée au risque

## V1.0.1 — Correctifs d’outillage et de façade (candidat)

Version corrective issue de l’audit `DG-AUDIT-001` (lot 1, phase 11.01). **Aucune règle normative de `DIRECTION.md`, `ACTION.md`, `SAVOIR.md` ou `BIBLIOTHEQUE.md` n’est modifiée.** Les changements portent sur les contrôles machine, l’accès aux sections et l’alignement des façades sur leurs propriétaires.

- **Contrôles machine.** Un schéma vide, non objet ou sans champ requis n’est plus admis ; chaque enum gardé et chaque champ requis atteint par l’exemple est muté et doit être rejeté. Les clés JSON répétées et l’UTF-8 invalide deviennent des diagnostics ; une entrée hors contrat ne produit plus d’exception brute. Chaque fixture négative de la suite native déclare son motif attendu ; le runner global vérifie ce motif et résout les fixtures depuis la racine du package.
- **Distributions.** Le build refuse les liens symboliques, crée des archives neuves, compare chaque archive à la liste du manifest de son profil, publie archives et `dist` ensemble et restaure la dernière distribution après une publication interrompue. Le validateur documentaire contrôle l’unicité du manifest, sa version face à ce CHANGELOG et les répertoires générés seulement à la racine.
- **Accès aux sections.** `READING_MAP.md` sert désormais tous les locators cités par le package (70 au lieu de 24), dont `ACTION/HANDOFF`, `ACTION/STATUS`, `ACTION/PRECONDITION`, `SAVOIR/SOURCE` et `SAVOIR/TOOLS`. L’extraction ignore les titres placés dans un bloc de code et refuse un titre ambigu.
- **Façades.** `ACTION/RUN-DIRECTION`, les minima `SYSTÈME` et les contrôles applicables de `ACTION/GATE-A` ne sont plus présentés comme des ajouts facultatifs dans `READING_MAP.md`, `ORCHESTRATION_MAP.md` et `QUICKSTART.md` ; `ITER` exige une direction retrouvable dans le README ; un craft qui ne redéfinit pas la direction reste `ITER` ; la skill restitue les champs complets d’`ACTION/HANDOFF` et nomme le dossier officiel des deux profils ; le flux de référence montre la reprise après protection critique et après `NOT-VERIFIED`. Un contrôle empêche une route de mode d’apparaître en ajout conditionnel.
- **CI.** Le workflow utilise `actions/checkout@v5` et `actions/setup-python@v6`, qui s’exécutent sous Node 24.

**Limites.** Ces contrôles protègent l’intégrité de la projection et des distributions ; ils ne prouvent ni la réalité d’un run, ni la qualité d’un rendu, ni l’usage. Aucun run CI hébergé n’a encore été observé pour V1.0.1.

## V1.0.0 — Baseline expérimentale

Design Governance V1.0.0 est une baseline publique cohérente pour diriger, construire, juger et vérifier un travail de design. Elle transforme un brief en décision située, artefact réel, observation pertinente et trace proportionnée au risque.

La baseline comprend :

- les cinq sources normatives de `V1/official/` ;
- les guides d’entrée, le glossaire, `READING_MAP.md` et `ORCHESTRATION_MAP.md` ;
- la skill pratique et ses références conditionnelles ;
- les contrats machine, exemples et fixtures ;
- les validateurs documentaires, de contrats et de `RUN_CARD` ;
- les contrôles de build et les distributions GitHub et Local.

La cohérence documentaire, les contrats machine, les liens, les fixtures et la reproductibilité des distributions sont contrôlés. **L’efficacité sur des runs réels, l’adoption, la charge cognitive, la qualité perceptuelle produite et la performance en production restent `NOT-VERIFIED`.**

## Autorité et maintenance

Les cinq sources normatives sont `DIRECTION.md`, `ACTION.md`, `SAVOIR.md`, `BIBLIOTHEQUE.md` et ce fichier. Les guides d’entrée et les cartes dérivées orientent la lecture sans créer de règle concurrente. Le schéma `RUN_CARD` et ses validateurs définissent les projections machine dans leur périmètre.

Toute évolution de la baseline doit identifier une source normative unique, un propriétaire, le périmètre concerné, la compatibilité, la preuve attendue, la limite, la prochaine revue et la procédure de retour. Une évolution ne devient une règle transversale qu’après décision explicite du propriétaire du corpus.

L’historique détaillé de construction et de travail est conservé hors de la distribution publique. Il n’est pas requis pour lire, utiliser ou valider V1.

## Cycle de vie des routes

Les statuts de route décrivent la maintenance d’une route candidate ou canonique. Ils ne sont pas des verdicts de design.

| Statut | Sens | Transition autorisée |
|---|---|---|
| `PILOT` | Route locale ou candidate testée dans un périmètre déclaré. | `ADOPTED` ou `ABANDONED`. |
| `ADOPTED` | Route canonique dont le contrat, la maintenance et le gain sont acceptés. | `DEPRECATED`. |
| `DEPRECATED` | Route conservée pour migration ou compatibilité ; elle ne doit pas être choisie dans un nouveau run. | `ABANDONED` après migration. |
| `ABANDONED` | Route qui n’est plus maintenue ni proposée. | Aucune transition silencieuse. |

Les routes présentes dans le seed de la V1 constituent la baseline canonique. Toute nouvelle route ou promotion doit indiquer son problème, sa décision, son owner, son contrat, sa preuve, sa limite, sa compatibilité et sa prochaine revue.

## Migration des anciens aliases

Les aliases historiques suivants ne sont pas des routes actives. Ils sont reclassés selon ce qu’ils établissent réellement ; l’ancien identifiant peut être conservé dans une trace de compatibilité.

| Alias | Reclassification publique |
|---|---|
| `REFERENCES/QUERY` | `SAVOIR/TOOLS` pour une recherche ou un claim à vérifier. |
| `REFERENCES/SOURCE` | `SAVOIR/SOURCE` pour une ancre ou une référence observée. |
| `REFERENCES/ASSET` | `DIRECTION/VISUAL_TARGET` pour la route et le rôle de production ; `SAVOIR/SOURCE` pour provenance et limite. |
| `REFERENCES/MEMORY` | `TRACE-LOCATOR` et artefact local ; une mémoire ne devient pas une source normative. |
| `REFERENCES/CORPUS` | Le propriétaire normatif réellement concerné ; `CHANGELOG` seulement si le contenu modifie le package. |

Une reclassification ambiguë reste `NOT-VERIFIED` ou `EXPLORATORY` jusqu’à ce que son propriétaire et sa portée soient établis.

## Limites de la baseline

Une validation de package ou de `RUN_CARD` confirme uniquement les contrôles exécutés. Elle ne remplace ni l’observation d’un rendu, ni un test utilisateur, ni une vérification d’accessibilité exécutée, ni une mesure de performance, ni une preuve d’adoption.

La baseline reste expérimentale. Toute conclusion d’usage doit préciser ce qui a été observé, par quelle méthode, dans quel scope et avec quelle limite.

