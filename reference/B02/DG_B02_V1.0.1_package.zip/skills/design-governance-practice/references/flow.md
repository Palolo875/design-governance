# Flux de décision V1

Le flux suivant est une vue de lecture, pas une route supplémentaire :

```mermaid
flowchart LR
  A[Classer] --> B[Protéger]
  B --> C[Cultiver et diriger]
  C --> D[Composer et construire]
  D --> E[Polir et observer]
  E --> F[Vérifier et corriger]
  F --> G[Décider et fermer]
  A -. risque critique .-> H[Protection de niveau]
  H -- reclasser, protéger d’abord --> B
  F -. preuve absente .-> I[NOT-VERIFIED]
  I -- réserve, owner et prochaine preuve --> G
  I -. preuve obtenable .-> F
  E -. défaut créatif .-> C
```

En texte : **classer et protéger le run, cultiver et diriger la décision, composer et construire l’artefact, polir et observer le rendu, vérifier et corriger ce qui est observable, puis décider et fermer avec ses limites**. La boucle créative élève le résultat ; la boucle de gouvernance protège le risque, la preuve et la vérité de ce qui peut être affirmé. Un risque critique ne s’arrête pas à la protection : le run est reclassé si nécessaire, puis repris une fois la protection posée. Une preuve absente ne devient jamais `PASS` : soit elle est obtenue et la vérification reprend, soit le run se ferme avec la réserve `NOT-VERIFIED`, l’owner et la prochaine preuve.

Charger `DIRECTION/START` avant un build, une modification, une vérification, une action externe ou une décision persistante. Charger les routes approfondies uniquement si elles peuvent modifier une décision, un artefact, une preuve, une limite ou la prochaine action.

Pour composer plusieurs capacités selon un résultat recherché — direction, beauté située, créativité, usage, preuve, vitesse ou système — consulter `ORCHESTRATION_MAP.md` dans la carte officielle du package. Cette carte complète le flux sans créer de route supplémentaire.

