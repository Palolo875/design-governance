const { chromium } = require('playwright'); const path=require('path');
(async()=>{
 const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',proxy:process.env.HTTPS_PROXY?{server:process.env.HTTPS_PROXY}:undefined});
 const p=await (await b.newContext({viewport:{width:1280,height:900},reducedMotion:'reduce',ignoreHTTPSErrors:true})).newPage();
 const errs=[]; p.on('pageerror',e=>errs.push(e.message));
 await p.goto('file://'+path.resolve(__dirname,'../index.html')+'?t=06:30&j=2',{waitUntil:'networkidle'});
 const seen=[];
 for(let i=0;i<16;i++){ await p.keyboard.press('Tab'); seen.push(await p.evaluate(()=>{const a=document.activeElement;return (a.id||a.name||a.textContent.trim().slice(0,22))+'|'+getComputedStyle(a).outlineStyle}));}
 console.log(seen.join('\n'));
 await p.focus('#size-20'); await p.keyboard.press('ArrowRight');
 await p.locator('#sizes').screenshot({path:path.resolve(__dirname,'kbd_chip.png')});
 console.log('anim under reduce:', await p.evaluate(()=>getComputedStyle(document.getElementById('four'),'::after').animationName), 'state', await p.evaluate(()=>document.getElementById('four').dataset.state));
 console.log(errs.length?errs:'no-errors'); await b.close();})();
