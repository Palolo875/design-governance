const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const proxy = process.env.HTTPS_PROXY ? { server: process.env.HTTPS_PROXY } : undefined;
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', proxy, args:['--ignore-certificate-errors'] });
  const file = 'file://' + path.resolve(__dirname, '../index.html');
  const cases = JSON.parse(process.argv[2]);
  for (const c of cases) {
    const ctx = await browser.newContext({ viewport: { width: c.w, height: c.h }, reducedMotion: c.rm ? 'reduce' : 'no-preference', ignoreHTTPSErrors: true });
    const page = await ctx.newPage();
    const errs = [];
    page.on('pageerror', e => errs.push(e.message));
    page.on('console', m => { if (m.type()==='error') errs.push(m.text()); });
    await page.goto(file + (c.q || ''), { waitUntil: 'networkidle' }).catch(e=>errs.push('goto '+e.message));
    await page.waitForTimeout(600);
    if (c.js) await page.evaluate(c.js);
    await page.waitForTimeout(300);
    const fonts = await page.evaluate(() => [...document.fonts].filter(f=>f.status==='loaded').map(f=>f.family).join(','));
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    if (c.sel) await page.locator(c.sel).screenshot({ path: path.resolve(__dirname, c.name + '.png') }); else await page.screenshot({ path: path.resolve(__dirname, c.name + '.png'), fullPage: !!c.full });
    console.log(c.name, 'fonts=', fonts, 'overflowX=', overflow, errs.length ? 'ERR ' + errs.join(' | ') : 'no-errors');
    await ctx.close();
  }
  await browser.close();
})();
