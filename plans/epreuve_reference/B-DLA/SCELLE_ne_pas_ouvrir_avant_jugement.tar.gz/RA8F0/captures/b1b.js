const { chromium } = require('playwright');
const path = require('path');
const file = 'file://' + path.resolve(__dirname, '..', 'index.html') + '?heure=0712';
const VARIANT = `.board{background:var(--paper)!important;color:var(--cocoa)!important;border:2px solid var(--cocoa)}
.board .clock,.board .clock strong,.board .note,.row .what small{color:var(--cocoa-2)!important}
.board-head,.plan{border-color:var(--cocoa)!important}.row{border-top-color:rgba(42,25,17,.25)!important}
.summary b{color:var(--crust-deep)!important}.row.past{color:rgba(42,25,17,.5)!important}
.row.next .tag{background:var(--cocoa)!important;color:var(--cream)!important;border-color:var(--cocoa)!important}
.plan .btn{border-color:var(--cocoa)!important;color:var(--cocoa)!important}`;
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell', args:['--proxy-server='+(process.env.HTTPS_PROXY||'')]});
  for (const [n,vp] of [['desk',{width:1440,height:900}],['mob',{width:390,height:844}]]) {
    const page = await (await browser.newContext({viewport:vp, ignoreHTTPSErrors:true})).newPage();
    await page.goto(file,{waitUntil:'networkidle'});
    if (n==='mob') await page.evaluate(()=>window.scrollTo(0,560));
    await page.screenshot({path:path.join(__dirname,`b1b-${n}-avant-planche-sombre.png`)});
    await page.addStyleTag({content:VARIANT});
    await page.screenshot({path:path.join(__dirname,`b1b-${n}-apres-planche-claire.png`)});
    // mobile full to check the whole page after fixes
    if (n==='mob'){ await page.reload({waitUntil:'networkidle'}); await page.screenshot({path:path.join(__dirname,'v3-mob-full.png'),fullPage:true}); }
  }
  await browser.close(); console.log('ok');
})();
