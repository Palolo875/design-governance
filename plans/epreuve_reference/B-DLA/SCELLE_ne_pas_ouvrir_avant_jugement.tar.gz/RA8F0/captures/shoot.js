const { chromium } = require('playwright');
const path = require('path');
const file = 'file://' + path.resolve(__dirname, '..', 'index.html');
const tag = process.argv[2] || 'v1';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell', args:['--proxy-server='+(process.env.HTTPS_PROXY||'')] , ignoreHTTPSErrors:true});
  const errors = [];
  for (const [name, vp, q] of [['desk-0712', {width:1440,height:900}, '?heure=0712'], ['mob-0712', {width:390,height:844}, '?heure=0712'], ['desk-2130', {width:1440,height:900}, '?heure=2130']]) {
    const ctx = await browser.newContext({ viewport: vp, deviceScaleFactor: 1, ignoreHTTPSErrors:true });
    const page = await ctx.newPage();
    page.on('pageerror', e => errors.push(name+': '+e.message));
    page.on('console', m => { if (m.type()==='error') errors.push(name+' console: '+m.text()); });
    await page.goto(file + q, { waitUntil: 'networkidle' });
    await page.evaluate(() => document.fonts.ready);
    const fonts = await page.evaluate(() => [...document.fonts].filter(f=>f.status==='loaded').map(f=>f.family+' '+f.weight));
    console.log(name, 'fonts:', [...new Set(fonts)].slice(0,6).join(', '));
    await page.screenshot({ path: path.join(__dirname, `${tag}-${name}-top.png`) });
    if (name !== 'desk-2130') await page.screenshot({ path: path.join(__dirname, `${tag}-${name}-full.png`), fullPage: true });
    const ov = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    console.log(name, 'horizontal overflow px:', ov);
    await ctx.close();
  }
  console.log('errors:', errors.length ? errors.join('\n') : 'none');
  await browser.close();
})();
