const { chromium } = require('playwright'); const path=require('path');
(async()=>{const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell',args:['--proxy-server='+(process.env.HTTPS_PROXY||'')]});
const p=await (await b.newContext({viewport:{width:390,height:844},ignoreHTTPSErrors:true,reducedMotion:'reduce'})).newPage();
const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+path.resolve(__dirname,'..','index.html')+'?heure=0712',{waitUntil:'networkidle'});
await p.locator('.slip').screenshot({path:path.join(__dirname,'v4-mob-slip.png')});
console.log('overflow',await p.evaluate(()=>document.documentElement.scrollWidth-innerWidth),'errors',errs.length);
const d=await p.evaluate(()=>{const x=new Date(Date.UTC(2026,9,1));return x.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long',timeZone:'UTC'}).replace(/(^|\s)1(\s)/,'$11er$2')});console.log(d);
await b.close();})();
