const { chromium } = require('playwright');
const path = require('path');
const file = 'file://' + path.resolve(__dirname, '..', 'index.html');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell', args:['--proxy-server='+(process.env.HTTPS_PROXY||'')]});
  const errors=[];
  for (const [name, vp] of [['desk',{width:1440,height:900}],['mob',{width:390,height:844}]]) {
    const ctx = await browser.newContext({ viewport: vp, ignoreHTTPSErrors:true });
    const page = await ctx.newPage();
    page.on('pageerror', e => errors.push(e.message));
    await page.goto(file + '?heure=1812', { waitUntil: 'networkidle' });
    await page.evaluate(() => { window.__opened=[]; window.open = (u)=>{ window.__opened.push(u); return {}; }; });
    // état : erreur (date trop tôt + livraison sans quartier)
    await page.check('input[name=mode][value=livraison]', {force:true});
    const tomorrow = await page.evaluate(()=>new Date(Date.now()+3600000+86400000).toISOString().slice(0,10));
    await page.fill('#date', tomorrow);
    await page.click('button[type=submit]');
    const focused = await page.evaluate(()=>document.activeElement.id);
    const errs = await page.evaluate(()=>[document.getElementById('date-err').textContent, document.getElementById('q-err').textContent, document.getElementById('status').textContent]);
    console.log(name,'ERROR STATE focus=',focused,'|',errs.join(' | '));
    await page.locator('#gateaux').screenshot({ path: path.join(__dirname, `v2-${name}-gateaux-erreur.png`) });
    // état valide
    await page.check('input[name=parfum][value=coco]', {force:true});
    await page.check('input[name=parts][value="50"]', {force:true});
    await page.fill('#inscription', 'Joyeux anniversaire Maman Rose, 60 ans !');
    const d = await page.evaluate(()=>new Date(Date.now()+3600000+5*86400000).toISOString().slice(0,10));
    await page.fill('#date', d);
    await page.selectOption('#quartier', 'Bonamoussadi');
    await page.fill('#prenom', 'Estelle');
    await page.click('button[type=submit]');
    const opened = await page.evaluate(()=>window.__opened);
    console.log(name,'VALID STATE status=', await page.textContent('#status'));
    if (name==='desk') console.log('URL decoded:\n'+decodeURIComponent(opened[0]||'none'));
    await page.locator('#gateaux').screenshot({ path: path.join(__dirname, `v2-${name}-gateaux-valide.png`) });
    // tableau à 18h12 (aucune fournée chaude) et en planifiant 12h20
    await page.locator('.board').screenshot({ path: path.join(__dirname, `v2-${name}-board-1812.png`) });
    await page.locator('#when').fill('740');
    await page.locator('.board').screenshot({ path: path.join(__dirname, `v2-${name}-board-plan-1220.png`) });
    // clavier : tab depuis le début
    await page.goto(file + '?heure=0712'); await page.keyboard.press('Tab'); await page.keyboard.press('Tab');
    const t = await page.evaluate(()=>document.activeElement.textContent.trim().slice(0,30));
    console.log(name,'2nd tab focus:',t);
    await page.screenshot({ path: path.join(__dirname, `v2-${name}-top.png`) });
    // reduced motion
    await ctx.close();
  }
  console.log('errors:', errors.length?errors:'none');
  await browser.close();
})();
